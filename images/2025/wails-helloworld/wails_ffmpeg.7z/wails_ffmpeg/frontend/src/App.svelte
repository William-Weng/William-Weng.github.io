<script>
  import logo from './assets/images/FFmpeg.png'
  import {Greet} from '../wailsjs/go/main/App.js'

  let placeholder = "請把要轉檔的影片路徑輸入到這裡 👇"
  let name

  function convert() {
    Greet(name).then(result => placeholder = result)
  }

  // 前端定義載入狀態
  let isLoading = false

  // 開始載入
  function startLoading() {
      isLoading = true
      document.querySelector('.loading').classList.add('show')
  }

  // 結束載入
  function endLoading() {
      isLoading = false
      document.querySelector('.loading').classList.remove('show')
  }
</script>

<main>
  <img alt="logo" id="logo" src="{logo}">
  <div class="input-box" id="input">
    <input autocomplete="off" bind:value={name} class="input" id="name" type="text" placeholder={placeholder}/>
    <button class="btn" on:click={convert}>轉換</button>
    <div class="loading">
      <div class="spinner"></div>
      <p>載入中...</p>
    </div>
  </div>
</main>

<style>

  #logo {
    display: block;
    width: 20%;
    height: 20%;
    margin: auto;
    padding: 10px 0;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-origin: content-box;
  }

  .input-box .btn {
    width: 60px;
    height: 30px;
    line-height: 30px;
    border-radius: 3px;
    border: none;
    margin: 0 0 0 20px;
    padding: 0 8px;
    cursor: pointer;
  }

  .input-box .btn:hover {
    background-image: linear-gradient(to top, #cfd9df 0%, #e2ebf0 100%);
    color: #333333;
  }

  .input {
    width: 50%;
  }

  .input-box .input {
    border: none;
    border-radius: 3px;
    outline: none;
    height: 30px;
    line-height: 30px;
    padding: 0 10px;
    background-color: rgba(240, 240, 240, 1);
    -webkit-font-smoothing: antialiased;
  }

  .input-box .input:hover {
    border: none;
    background-color: rgba(255, 255, 255, 1);
  }

  .input-box .input:focus {
    border: none;
    background-color: rgba(255, 255, 255, 1);
  }

  .loading {
      display: none;
  }

  .loading.show {
      display: flex;
      align-items: center;
      justify-content: center;
  }

  .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #3498db;
      border-radius: 50%;
      animation: spin 1s linear infinite;
  }

  @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
  }

</style>
