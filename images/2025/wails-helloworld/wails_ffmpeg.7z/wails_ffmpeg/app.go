package main

import (
	"context"
	"fmt"
	"os/exec"
	"path/filepath"

	"github.com/wailsapp/wails/v2/pkg/runtime"
)

// App struct
type App struct {
	ctx context.Context
}

// NewApp creates a new App application struct
func NewApp() *App {
	return &App{}
}

// startup is called when the app starts. The context is saved
// so we can call the runtime methods
func (a *App) startup(ctx context.Context) {
	a.ctx = ctx
}

// Greet returns a greeting for the given name
func (app *App) Greet(name string) string {

	err := convertToHLS(name)

	if err != nil {
		messageDialog(app, err.Error())
		return fmt.Sprintf("Error,s %s", err)
	}

	messageDialog(app, "Success!!!")
	return fmt.Sprintf("Success, %s", name)
}

func convertToHLS(fullPath string) error {

	dirPath := filepath.Dir(fullPath)
	// filename := filepath.Base(fullPath)
	hlsDir := dirPath + "/hls"

	println(hlsDir)

	cmd := exec.Command("mkdir",
		"-p", hlsDir,
	)
	cmd.Run()

	cmd = exec.Command("ffmpeg",
		"-i", fullPath,
		"-profile:v", "baseline",
		"-level", "3.0",
		"-start_number", "0",
		"-hls_time", "10",
		"-s", "640x480",
		"-hls_list_size", "0",
		"-f", "hls",
		hlsDir+"/playlist.m3u8")

	err := cmd.Run()

	if err != nil {
		return err
	}

	return nil
}

func messageDialog(app *App, message string) {

	runtime.MessageDialog(app.ctx, runtime.MessageDialogOptions{
		Type:    runtime.InfoDialog,
		Title:   "提示",
		Message: message,
	})
}
