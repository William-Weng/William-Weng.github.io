import { invoke } from "@tauri-apps/api/core";

// 標籤顏色對照表
const Colors: { background: string; text: string }[] = [
  { background: '#1abc9c', text: '#ffffff' },   // 綠松石
  { background: '#e67e22', text: '#ffffff' },   // 橘色
  { background: '#e74c3c', text: '#ffffff' },   // 紅色
  { background: '#2980b9', text: '#ffffff' },   // 深藍
  { background: '#8e44ad', text: '#ffffff' },   // 紫色
  { background: '#f1c40f', text: '#ffffff' },   // 黃色
  { background: '#2ecc71', text: '#ffffff' },   // 綠色
  { background: '#34495e', text: '#ffffff' },   // 深灰藍
  { background: '#ff6f61', text: '#ffffff' },   // 珊瑚紅
  { background: '#00bcd4', text: '#ffffff' },   // 藍綠
];

// 定義類型顏色對照表
const TypeColors: { [key: string]: { background: string; text: string } } = {
  "Windows": Colors[0],
  "macOS": Colors[1],
  "Linux": Colors[2],
  "Android": Colors[3],
  "iOS": Colors[4],
  "Swift": Colors[0],
  "SwiftUI": Colors[1],
  "Objective-C": Colors[2],
  "Xcode": Colors[3],
  "Portfolio": Colors[0],
  "Idea": Colors[1],
  "Icon": Colors[2],
  "Music": Colors[3],
  "Font": Colors[4],
  "PPT": Colors[5],
  "Sound": Colors[6],
  "Image": Colors[7],
  "3D": Colors[8],
  "UI / UX": Colors[9],
  "Video": Colors[0],
  "IDE": Colors[1],
  "Subtitle": Colors[2],
  "Youtube": Colors[3],
  "Database": Colors[4],
  "TV": Colors[5],
  "Electron": Colors[6],
  "AI": Colors[7],
  "Color": Colors[8],
  "Audio": Colors[9],
  "JSON": Colors[0],
  "PDF": Colors[2],
  "BaaS": Colors[3],
  "API": Colors[5],
  "HTML": Colors[6],
  "QR-Code": Colors[7],
  "Gallery": Colors[8],
  "Document": Colors[9],
  "File": Colors[1],
}

// Rust後端函數對照表
const RustFunctions = {
  "readCsvList": "csv_list",
  "readCsvContent": "read_csv"
}

let platformSelect: HTMLInputElement | null;
let collectionView: HTMLElement | null;
let loader: HTMLElement | null;
let darkModeSwitch: HTMLInputElement | null;

/**
  * 從指定的 CSV 檔案中讀取資料，並將每一行資料轉換為 HTML 卡片格式
  * @returns {Promise<void>} - 返回一個 Promise，表示操作完成
  */
async function displayCsvCard(platform?: string) {

  if (!platformSelect || !collectionView) { return; }
  const filename = (platform || "Linux.csv");
  
  collectionView.innerHTML = "";
  displayLoader();

  try {
    const jsonString = new String(await invoke(RustFunctions["readCsvContent"], { filename: filename })).valueOf();
    const response = JSON.parse(jsonString) as Record<string, any>;
    const array = response.result as Array<Record<string, any>>;

    for (const row of array) {
      const divHtml = collectionItemMaker(row);
      collectionView.insertAdjacentHTML('beforeend', divHtml);
    }

    await new Promise(resolve => setTimeout(resolve, 1000));

  } catch (error) {
    console.error("Error reading CSV file:", error);
  } finally {
    dismissLoader();
    collectionView.style.opacity = '1.0';
  }
}

/**
  * 將csv檔案的每一行資料轉換為HTML卡片格式
  * @param {Record<string, any>} row - CSV 檔案中的一行資料
  * @returns {string} - 返回一個包含 HTML 卡片的字符串
  */
function collectionItemMaker(row: Record<string, any>) {

  const stars = '★'.repeat(Number(row.level) || 0) + '☆'.repeat(5 - (Number(row.level) || 0));

  const divHtml = `
    <div class="card">
        <div class="star-rating">${stars}</div>
        <h2 class="card-link"><a href="${row.url}" target="_blank">${row.name}</a></h2>
        <p class="card-notes">${row.notes}</p>
        ${row.example ? `<p class="card-example">${row.example}</p>` : ''}
        <div class="hashtag-container">
          ${hashtagHtmlElementMaker(row.platform)}
          ${hashtagHtmlElementMaker(row.type)}
        </div>
    </div>
    `

  return divHtml;
}

/**
  * 將標籤值轉換為 HTML 元素
  * @param {string[]} tags - 標籤值的數組
  * @returns {string} - 返回一個包含 HTML 標籤的字符串
  */
function hashtagHtmlElementMaker(tags?: [string]) {

  if (!tags) { return '' };
  let hashtags: string[] = [];

  tags.forEach((tag: string, index: number) => {
    let color = TypeColors[tag] ?? Colors[index % Colors.length];
    let html = `<span class="hashtag" style="background-color: ${color.background}; color: ${color.text}">${tag}</span>`;
    hashtags.push(html);
  });

  return hashtags.join('');
}

/**
  * 初始化平台選擇器的選項
  * @returns {void}
  */
async function initMenuSetting() {

  if (!platformSelect) return;
  platformSelect.innerHTML = "";  

  let jsonString = new String(await invoke(RustFunctions["readCsvList"])).valueOf();
  let response = JSON.parse(jsonString);
  let list = response.result as string[];

  list.forEach((filename, index) => {

    const option = document.createElement('option');

    if (index === 0) { option.selected = true; }
    option.value = filename;
    option.textContent = filename;

    platformSelect?.appendChild(option);
  });
}

/**
  * 顯示加載器
  * @returns {void}
  */
function displayLoader() { loader?.classList.add('active'); }

/**
  * 隱藏加載器
  * @returns {void}
  */
function dismissLoader() { loader?.classList.remove('active'); }

// 初始化深色模式
function initDarkMode() {
  darkModeSwitch = document.querySelector('#switch');
  if (!darkModeSwitch) return;

  // 檢查本地儲存的主題偏好
  const isDarkMode = localStorage.getItem('darkMode') === 'true';
  darkModeSwitch.checked = isDarkMode;
  document.documentElement.classList.toggle('dark-mode', isDarkMode);

  // 監聽切換事件
  darkModeSwitch.addEventListener('change', () => {
    document.documentElement.classList.toggle('dark-mode', darkModeSwitch?.checked);
    localStorage.setItem('darkMode', String(darkModeSwitch?.checked));
  });
}

/**
  * 主程式設定，設置平台選擇器和顯示 CSV 卡片
  * @returns {Promise<void>} - 返回一個 Promise，表示操作完成
  */
async function main() {

  platformSelect = document.querySelector("#platform-select");
  collectionView = document.querySelector("#card-collection-view");
  loader = document.querySelector('#loader-container');
  
  await initMenuSetting();
  initDarkMode();
  
  if (!platformSelect || !collectionView) { return; }

  platformSelect?.addEventListener("change", () => displayCsvCard(platformSelect?.value));
  await displayCsvCard(platformSelect.value);
}

main();