## [編譯方式](https://william-weng.github.io/2025/06/tauri當rust跟web同在一起在一起在一起/)
```bash
npm install
npm run tauri dev
npm run tauri build
```