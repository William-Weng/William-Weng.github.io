<script setup lang="ts">
import { ref, onMounted } from "vue";
import { invoke } from "@tauri-apps/api/core";

// Rust後端函數對照表
const RustFunctions = {
  "readCsvList": "csv_list",
  "readCsvContent": "read_csv",
  "readColors": "read_json_file"
}

const switchRef = ref<HTMLInputElement | null>(null);
const searchBarRef = ref<HTMLInputElement | null>(null);
const platformRef = ref<HTMLSelectElement | null>(null);
const cardRef = ref<HTMLDivElement | null>(null);
const loaderContainer = ref<HTMLDivElement | null>(null);

const csvListRef = ref<string[]>([]);
const csvItemsRef = ref<Array<Record<string, any>>>([]);
const hashTagColorsRef = ref<any>({});

function changeDarkMode() {
  document.documentElement.classList.toggle('dark-mode', switchRef.value?.checked);
  localStorage.setItem('darkMode', String(switchRef.value?.checked));
}

async function displayCsvCard(isReset: Boolean = true) {

  if (isReset) { searchBarRef.value.value = ""; }

  const platform = platformRef?.value?.value?.trim();
  const filename = (platform || "Linux.csv");
  const keyword = searchBarRef?.value?.value?.trim();

  displayLoader();

  try {
    const jsonString = new String(await invoke(RustFunctions["readCsvContent"], { filename: filename })).valueOf();
    const response = JSON.parse(jsonString) as Record<string, any>;
    const items = response.result as Array<Record<string, any>>;
    
    if (!keyword) {
      csvItemsRef.value = items;
    } else {
      csvItemsRef.value = items.filter(item => {
        const values = Object.values(item).flat().join(' ');
        if (!values.toLowerCase().includes(keyword.toLowerCase())) { return false };
        return true;
      });
    }

    await new Promise(resolve => setTimeout(resolve, 1000));

  } catch (error) {
    console.error("Error reading CSV file:", error);
  } finally {
    dismissLoader();
  }
}

function starsCount(row: Record<string, any>) {
  return '★'.repeat(Number(row.level) || 0) + '☆'.repeat(5 - (Number(row.level) || 0))
}

function highlightAction(text: string) {
  const keyword = searchBarRef.value?.value?.trim();
  if (!keyword) return text;
  const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")})`, 'gi');
  return text.replace(regex, '<mark>$1</mark>');
}

async function readHashTagColors() {

  try {
    const jsonContent = await invoke(RustFunctions["readColors"], { filename: "hashTagColors.json" }) as string;
    return JSON.parse(jsonContent);
  } catch (error) {
    console.error("無法載入 hashtagColors.json:", error);
    return {};
  }
}

function displayLoader() { loaderContainer.value?.classList.add('active'); }

function dismissLoader() { loaderContainer.value?.classList.remove('active'); }

async function initMenuSetting() {

  const jsonString = new String(await invoke(RustFunctions["readCsvList"])).valueOf();
  const response = JSON.parse(jsonString);
  const list = response.result as string[];

  csvListRef.value = list;
}

function initDarkMode() {

  if (!switchRef.value) return;

  const isDarkMode = localStorage.getItem('darkMode') === 'true';
  switchRef.value.checked = isDarkMode;
  document.documentElement.classList.toggle('dark-mode', isDarkMode);
}

async function initHashTagColor() {
    hashTagColorsRef.value = await readHashTagColors();
}

function main() {
  
  initHashTagColor();
  initMenuSetting();
  initDarkMode();

  displayCsvCard(true);
}

onMounted(() => {
  main();
});
</script>

<template>
  <main id="container">
    <div id="platform-selector">
      <select id="platform-select" ref="platformRef" @change="displayCsvCard(true)">
        <option v-for="item in csvListRef" :key="item" :value="item">{{ item }}</option>
      </select>
    </div>
    <div class="switch-container">
      <input id="switch" type="checkbox" ref="switchRef" @change="changeDarkMode"/>
      <label for="switch">
        <span class="switch-txt"></span>
      </label>
    </div>
    <div id="loader-container" ref="loaderContainer">
      <div id="loader">
        <div id="loader-circle"></div>
        <div id="loader-text">載入中...</div>
      </div>
    </div>
    <div id="card-collection-view" ref="cardRef">
      <div class="card" v-for="item in csvItemsRef" :key="item.name" :value="item">
        <div class="star-rating">{{ starsCount(item) }}</div>
        <h2 class="card-link"><a :href="item.url" target="_blank" v-html="highlightAction(item.name)"></a></h2>
        <p class="card-notes">{{ item.notes }}</p>
        <p class="card-example" v-if="item.example" v-html="highlightAction(item.example)"></p>
        <div class="hashtag-container">
          <template v-if="item.platform">
            <span class="hashtag" v-for="platform in item.platform" :key="platform" v-html="highlightAction(platform)" :style="{ backgroundColor: hashTagColorsRef[platform]?.background || '#e0e0e0', color: hashTagColorsRef[platform]?.text || '#000' }"></span>
          </template>
          <template v-if="item.type">
            <span class="hashtag" v-for="type in item.type" :key="type" v-html="highlightAction(type)" :style="{ backgroundColor: hashTagColorsRef[type]?.background || '#e0e0e0', color: hashTagColorsRef[type]?.text || '#000' }"></span>
          </template>
        </div>
      </div>
    </div>
    <div class="search-bar-bottom">
      <div class="search">
        <input id="search-bar" type="text" name="search" ref="searchBarRef" placeholder="輸入名稱" @keyup.enter="displayCsvCard(false)">
        <button id="search-btn" @click="displayCsvCard(false)"><img src="/src/assets/search.png" alt="搜尋"></button>
      </div>
    </div>
  </main>
</template>

<style>
/* CSS 變量定義 */
:root {
  /* 容器尺寸 */
  --max-width: 1440px;
  --card-width: 300px;
  --header-height: 60px;
  --foot-height: 36px;
  --selector-width: 200px;

  /* 開關高度 */
  --switch-height: 30px;

  /* 顏色系統 */
  --color-background-rgb: 255, 255, 255;
  --color-primary-rgb: 44, 82, 130;
  --color-primary: #2c5282;
  --color-secondary: #4299e1;
  --color-selector: #2c5282;
  --color-selector-secondary: #4299e1;
  --color-accent: #24c8db;
  --color-background: #f6f6f6;
  --color-text: #0f0f0f;
  --color-link: #646cff;
  --color-link-hover: #535bf2;
  --color-button: #ffffff;
  --color-notes-bg: #e9e4e5;
  --color-placeholder-text: #ebeef4;
  --color-example-bg: #1a1a1a;
  --color-example-text: #fffff0;
  --color-card-bg: white;
  --color-switch-bg: white;
  --color-switch-border: #2c5282;
  --color-header-bg: #f0f4f8;
  --color-hashtag-bg: #e2e8f0;
  --color-note-text: #4a5568;
  --color-star: #ffd700;
  --color-star-bg: #2980b9;
  --color-overlay: rgba(0, 0, 0, 0.1);

  /* 字體系統 */
  --font-family-base: Inter, Avenir, Helvetica, Arial, sans-serif;
  --font-family-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  --font-size-xs: 0.75em;
  --font-size-sm: 0.85em;
  --font-size-base: 16px;
  --font-size-lg: 1.2em;
  --font-size-xl: 1.5em;
  --line-height-base: 1.5;
  --line-height-tight: 1.25;
  --line-height-relaxed: 1.75;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-bold: 600;

  /* 間距系統 */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 12px;
  --spacing-lg: 16px;
  --spacing-xl: 20px;
  --spacing-2xl: 24px;
  --gap-cards: 40px;

  /* 陰影系統 */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 2px 4px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 2px 8px rgba(0, 0, 0, 0.2);
  --shadow-text: 0 1px 2px rgba(0, 0, 0, 0.2);

  /* 圓角系統 */
  --radius-sm: 4px;
  --radius-md: 6px;
  --radius-lg: 8px;
  --radius-full: 9999px;

  /* 動畫系統 */
  --transition-fast: 0.2s ease;
  --transition-normal: 0.3s ease;
  --transition-slow: 0.75s;
  --animation-duration: 1s;
  --animation-timing: linear;

  /* Z-index 系統 */
  --z-header: 100;
  --z-loader: 1000;
}

/* 基礎樣式重置 */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* 基礎樣式 */
body {
  font-family: var(--font-family-base);
  font-size: var(--font-size-base);
  line-height: var(--line-height-base);
  font-weight: var(--font-weight-normal);
  color: var(--color-text);
  background-color: var(--color-background);
  text-rendering: optimizeLegibility;
}

/* 容器和佈局 */
#container {
  width: 100%;
  min-height: 100vh;
  margin: 0 auto;
  max-width: var(--max-width);
  padding-top: calc(var(--header-height) + var(--spacing-xl));
  padding-bottom: calc(var(--foot-height) + var(--spacing-xl));
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  text-align: center;
  align-items: center;
}

/* 平台選擇器 */
#platform-selector {
  top: 0;
  left: 0;
  right: 0;
  backdrop-filter: blur(8px);
  height: var(--header-height);
  z-index: var(--z-header);
  background-color: rgba(var(--color-background-rgb), 0.95);
  padding: var(--spacing-md) 0;
  box-shadow: var(--shadow-md);
  position: fixed;
  align-items: center;
  display: flex;
  justify-content: center;
  transition: transform var(--transition-normal);
}

#platform-selector select {
  margin: 0;
  padding-right: 32px;
  padding: var(--spacing-sm) var(--spacing-md);
  font-size: var(--spacing-xl);
  border: 2px solid var(--color-selector);
  border-radius: var(--radius-md);
  background-color: var(--color-card-bg);
  color: var(--color-selector);
  cursor: pointer;
  min-width: var(--selector-width);
  transition: all var(--transition-normal);
  appearance: none;
  background-size: 16px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right 8px center;
}

#platform-selector select:hover {
  border-color: var(--color-selector-secondary);
  box-shadow: var(--shadow-md);
  transform: translateY(-1px);
}

#platform-selector select:focus {
  outline: none;
  border-color: var(--color-selector-secondary);
  box-shadow: 0 0 0 3px rgba(var(--color-primary-rgb), 0.5);
}

/* 卡片集合 */
#card-collection-view {
  width: 100%;
  gap: var(--gap-cards);
  padding: var(--spacing-xl);
  max-width: var(--max-width);
  margin-bottom: var(--spacing-2xl);
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  box-sizing: border-box;
}

/* 卡片元件 */
.card {
  width: var(--card-width);
  background: var(--color-card-bg);
  border-radius: var(--radius-lg);
  padding: var(--spacing-lg) var(--spacing-md) var(--spacing-sm);
  box-shadow: var(--shadow-md);
  transition: transform var(--transition-normal), box-shadow var(--transition-normal);
  text-align: left;
  box-sizing: border-box;
  position: relative;
}

.card:hover {
  transform: translateY(-8px);
}

.card-link {
  margin: 0;
  padding: var(--spacing-sm) var(--spacing-md);
  font-size: var(--font-size-large);
  background-color: var(--color-header-bg);
  border-radius: var(--radius-md);
  color: var(--color-primary);
  font-weight: var(--font-weight-bold);
  box-shadow: var(--shadow-sm);
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.card-link a {
  color: var(--color-primary);
  transition: color var(--transition-fast);
  text-decoration: none;
}

.card-link a:hover {
  color: var(--color-secondary);
}

.card-notes {
  height: 7.5em;
  line-height: var(--line-height-base);
  background-color: var(--color-notes-bg);
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--radius-md);
  margin: var(--spacing-lg) 0;
  border: 1px solid var(--color-hashtag-bg);
  color: var(--color-note-text);
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: var(--color-hashtag-bg) transparent;
}

.card-example {
  height: 5.5em;
  line-clamp: 3;
  background-color: var(--color-example-bg);
  color: var(--color-example-text);
  text-shadow: var(--shadow-text);
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--radius-sm);
  margin: var(--spacing-sm) 0;
  font-family: var(--font-family-mono);
  font-size: var(--font-size-small);
  line-height: var(--line-height-base);
  overflow-y: auto;
  position: relative;
}

/* 評分標籤 */
.star-rating {
  z-index: 2;
  top: calc(-1 * var(--spacing-xl));
  left: calc(-1 * var(--spacing-xl));
  color: var(--color-star);
  background: var(--color-star-bg);
  font-size: var(--font-size-small);
  letter-spacing: 1px;
  text-shadow: var(--shadow-text);
  padding: var(--spacing-xs) var(--spacing-sm);
  border-radius: var(--radius-full);
  box-shadow: var(--shadow-md);
  white-space: nowrap;
  position: absolute;
  transform: scale(1.0);
}

/* Hashtag 樣式 */
.hashtag-container {
  display: flex;
  flex-wrap: wrap;
  gap: var(--spacing-sm);
  margin-top: var(--spacing-md);
  padding: var(--spacing-xs);
}

.hashtag {
  display: inline-block;
  padding: var(--spacing-xs) var(--spacing-md);
  margin: var(--spacing-);
  background-color: var(--color-hashtag-bg);
  color: var(--color-note-text);
  border-radius: var(--radius-full);
  font-size: var(--font-size-sm);
  font-weight: var(--font-weight-medium);
  transition: all var(--transition-fast);
  text-decoration: none;
  line-height: var(--line-height-tight);
}

.hashtag:hover {
  background-color: var(--color-secondary);
  color: var(--color-button);
  transform: translateY(-1px);
  box-shadow: var(--shadow-sm);
}

/* 深色模式切換開關 */
.switch-container {
  position: fixed;
  top: var(--spacing-md);
  right: var(--spacing-xl);
  z-index: var(--z-header);
}

/* 隱藏原始的 checkbox */
.switch-container input[type="checkbox"] {
  display: none;
}

/* 開關的外觀 */
.switch-container label {
  display: block;
  width: 60px;
  height: var(--switch-height);
  padding: 3px;
  border-radius: 15px;
  border: 2px solid var(--color-switch-border);
  cursor: pointer;
  transition: all var(--transition-fast);
  position: relative;
}

/* 開關的圓形按鈕 */
.switch-container label::before {
  content: "";
  display: block;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: var(--color-switch-border);
  transition: all var(--transition-fast);
}

/* 開關打開時的狀態 */
.switch-container input:checked + label {
  background-color: var(--color-primary);
}

/* 開關文字 */
.switch-txt {
  position: absolute;
  top: 50%;
  left: 100%;
  transform: translateY(-50%);
  margin-left: var(--spacing-sm);
  font-size: var(--font-size-sm);
  color: var(--color-text);
}

.switch-txt::before {
  content: attr(turnOff);
}

.switch-container input:checked + label .switch-txt::before {
  content: attr(turnOn);
}

.switch-container input:checked + label::before {
  transform: translateX(var(--switch-height));
}

/* 載入器樣式 */
#loader-container {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: var(--color-overlay);
  backdrop-filter: blur(4px);
  justify-content: center;
  align-items: center;
  z-index: var(--z-loader);
  opacity: 0;
  transition: opacity var(--transition-normal);
}

#loader-container.active {
  display: flex;
  opacity: 1;
}

#loader-container.active #loader {
  transform: translateY(0);
}

#loader {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--spacing-lg);
  transform: translateY(var(--spacing-xl));
  transition: transform var(--transition-normal);
}

#loader-circle {
  width: 48px;
  height: 48px;
  border: 4px solid rgba(var(--color-primary-rgb), 0.3);
  border-top: 4px solid var(--color-primary);
  border-radius: var(--radius-full);
  animation: spin var(--animation-duration) var(--animation-timing) infinite;
  box-shadow: var(--shadow-md);
}

#loader-text {
  color: var(--color-text);
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-medium);
  text-shadow: var(--shadow-text);
  opacity: 0;
  transform: translateY(var(--spacing-md));
  animation: fadeInUp 0.5s ease forwards 0.2s;
}

/* search-bar-bottom 置底樣式 */
.search-bar-bottom {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100vw;
  background-color: rgba(var(--color-background-rgb), 0.95);;
  box-shadow: 0 -2px 8px rgba(0,0,0,0.08);
  z-index: 100;
  padding: 12px 0 8px 0;
  display: flex;
  justify-content: center;
}

.search-bar-bottom .search {
  display: flex;
  align-items: center;
  gap: 8px;
}

#search-bar {
  width: 240px;
  padding: 8px 12px;
  border-radius: 20px;
  border: 1px solid var(--color-placeholder-text);
  font-size: 1rem;
  outline: none;
  transition: border 0.2s;
}

#search-bar:focus {
  border: 1.5px solid var(--color-selector);
}

#search-btn {
  height: var(--foot-height);
  padding: 0;
  border: none;
  border-radius: 50%;
  background-color: var(--color-placeholder-text);
  color: var(--color-card-bg);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  transition: background-color 0.25s;
  aspect-ratio: 1/1;
  box-sizing: border-box;
}

#search-btn:hover {
  background: var(--color-switch-border);
}

/* 動畫 */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(var(--spacing-md));
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes ripple {
  0% {
    transform: scale(0, 0);
    opacity: 0.5;
  }
  20% {
    transform: scale(25, 25);
    opacity: 0.3;
  }
  100% {
    transform: scale(40, 40);
    opacity: 0;
  }
}

/* 深色模式樣式 */
.dark-mode {
  --color-selector: #c6c6c6;
  --color-selector-secondary: #f6f6f6;
  --color-background: #2f2f2f;
  --color-background-rgb: 47, 47, 47;
  --color-text: #f6f6f6;
  --color-button: #0f0f0f98;
  --color-card-bg: #3f3f3f;
  --color-switch-bg: white;
  --color-switch-border: #f6f6f6;
  --color-header-bg: #c8d2de;
  --color-hashtag-bg: #4a5568;
  --color-note-text: #f6f6f6;
  --color-placeholder-text: #2f2f2f;
  --color-link-hover: #24c8db;
  --color-notes-bg: #4a5568;
  --color-example-text: #ffffff;
  --color-overlay: rgba(0, 0, 0, 0.2);
  --shadow-sm: 0 1px 2px rgba(255, 255, 255, 0.05);
  --shadow-md: 0 2px 4px rgba(255, 255, 255, 0.1);
  --shadow-lg: 0 2px 8px rgba(255, 255, 255, 0.15);
  --shadow-text: 0 1px 2px rgba(255, 255, 255, 0.2);
}
</style>