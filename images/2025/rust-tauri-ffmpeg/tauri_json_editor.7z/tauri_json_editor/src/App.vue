<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from "vue";
import JSONEditor from "jsoneditor";
import "jsoneditor/dist/jsoneditor.css";

const jsonData = ref<any>({ hello: "world" });
let editorCode: any = null;
let editorTree: any = null;
const editorCodeContainer = ref<HTMLElement | null>(null);
const editorTreeContainer = ref<HTMLElement | null>(null);
const lastChangedBy = ref<"code" | "tree" | null>(null);

function isEqual(a: any, b: any) {
  try {
    return JSON.stringify(a) === JSON.stringify(b);
  } catch {
    return false;
  }
}

onMounted(() => {
  if (editorCodeContainer.value) {
    editorCode = new JSONEditor(editorCodeContainer.value, {
      mode: "code",
      onChange: () => {
        if (lastChangedBy.value === "tree") return;
        try {
          const val = editorCode!.get();
          if (!isEqual(val, jsonData.value)) {
            jsonData.value = val;
            lastChangedBy.value = "code";
            if (editorTree && !isEqual(editorTree.get(), val)) {
              editorTree.set(val);
            }
          }
        } catch (e) {
        } finally {
          lastChangedBy.value = null;
        }
      }
    });
    editorCode.set(jsonData.value);
  }
  if (editorTreeContainer.value) {
    editorTree = new JSONEditor(editorTreeContainer.value, {
      mode: "tree",
      modes: ["tree", "view"],
      onChange: () => {
        if (lastChangedBy.value === "code") return;
        try {
          const val = editorTree!.get();
          if (!isEqual(val, jsonData.value)) {
            jsonData.value = val;
            lastChangedBy.value = "tree";
            if (editorCode && !isEqual(editorCode.get(), val)) {
              editorCode.set(val);
            }
          }
        } catch (e) {
        } finally {
          lastChangedBy.value = null;
        }
      }
    });
    editorTree.set(jsonData.value);
  }
});

onBeforeUnmount(() => {
  if (editorCode) {
    editorCode.destroy();
    editorCode = null;
  }
  if (editorTree) {
    editorTree.destroy();
    editorTree = null;
  }
});
</script>

<template>
  <main class="split-container">
    <div class="split left">
      <div ref="editorCodeContainer" class="editor-toolbar-red editor-fullsize"></div>
    </div>
    <div class="split right">
      <div ref="editorTreeContainer" class="editor-toolbar-green editor-fullsize"></div>
    </div>
  </main>
</template>

<style scoped>
.split-container {
  display: flex;
  flex-direction: row;
  max-width: 100vw;
  max-height: 100vh;
  height: 100vh;
  width: 100vw;
  margin: 0;
  padding: 32px;
  box-sizing: border-box;
  background: #181c20;
}
.split {
  flex: 1 1 50%;
  min-width: 0;
  max-width: 50%;
  height: 100%;
  display: flex;
  flex-direction: column;
}
.left {
  max-width: 50%;
  height: 100%;
  margin-right: 10px;
}
.right {
  max-width: 50%;
  height: 100%;
  margin-left: 10px;
}
.editor-fullsize {
  width: 100%;
  height: 100%;
}
.editor-toolbar-red :deep(.jsoneditor-menu),
.editor-toolbar-red :deep(.jsoneditor-poweredBy) {
  background: #d32f2f !important;
  color: #fff !important;
}
.editor-toolbar-green :deep(.jsoneditor-menu),
.editor-toolbar-green :deep(.jsoneditor-poweredBy) {
  background: #388e3c !important;
  color: #fff !important;
}
:deep(.jsoneditor),
:deep(.jsoneditor-outer),
:deep(.jsoneditor-inner),
:deep(.jsoneditor-tree),
:deep(.jsoneditor-menu),
:deep(.jsoneditor-poweredBy),
:deep(.jsoneditor-statusbar),
:deep(.jsoneditor-navigation-bar),
:deep(.jsoneditor-contextmenu),
:deep(.ace_editor),
:deep(.ace_scroller),
:deep(.ace_content),
:deep(.ace_text-input),
:deep(.ace_line),
:deep(.ace_gutter),
:deep(.ace_gutter-cell),
:deep(.ace_print-margin),
:deep(.ace_marker-layer),
:deep(.ace_cursor),
:deep(.ace_active-line),
:deep(.ace_selected-word),
:deep(.ace_selection) {
  background: #23272e !important;
  color: #b5e853 !important;
  border-color: #444 !important;
}
:deep(.ace_content),
:deep(.ace_line),
:deep(.ace_text-input),
:deep(.ace_static_text),
:deep(.ace_text-layer),
:deep(.ace_editor *),
:deep(.ace_editor .ace_text-layer),
:deep(.ace_editor .ace_line) {
  color: #b5e853 !important;
  background: transparent !important;
  font-size: 20px !important;
}
:deep(.ace_string) {
  color: #b5e853 !important;
}
:deep(.ace_numeric) {
  color: #f7b955 !important;
}
:deep(.ace_boolean) {
  color: #f7768e !important;
}
:deep(.ace_variable) {
  color: #6ab0f3 !important;
}
:deep(.ace_paren) {
  color: #b5e853 !important;
}
:deep(.ace_active-line) {
  background: #555c68 !important;
}
:deep(.ace_selection) {
  background: #555c68 !important;
}
:deep(.jsoneditor-highlight) {
  background-color: #555c68 !important;
  color: white !important;
}
:deep(.jsoneditor-tree tr.jsoneditor-selected > td),
:deep(.jsoneditor-tree tr.jsoneditor-selected > th) {
  background-color: #555c68 !important;
}
:deep(.jsoneditor-td-content),
:deep(.jsoneditor-tree td) {
  background-color: transparent !important;
}
:deep(.jsoneditor-field),
:deep(.jsoneditor-value),
:deep(.jsoneditor-string),
:deep(.jsoneditor-number),
:deep(.jsoneditor-boolean),
:deep(.jsoneditor-null) {
  color: #b5e853 !important;
  font-size: 20px !important;
  background-color: transparent !important;
}
:deep(.jsoneditor-field) {
  color: #6ab0f3 !important;
}
:deep(.jsoneditor-readonly) {
  color: #aaa !important;
  font-size: 20px !important;
}
:deep(.jsoneditor-menu button) {
  color: #fff !important;
}
:deep(.jsoneditor-contextmenu) {
  background: #23272e !important;
  color: #e0e0e0 !important;
  border-color: #444 !important;
}
:deep(.jsoneditor-contextmenu .jsoneditor-separator) {
  border-color: #444 !important;
}
:deep(.jsoneditor-contextmenu .jsoneditor-menu li button:hover) {
  background: #333 !important;
}
html, body {
  width: 100vw;
  height: 100vh;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background: #181c20;
  color: #e0e0e0;
}
</style>