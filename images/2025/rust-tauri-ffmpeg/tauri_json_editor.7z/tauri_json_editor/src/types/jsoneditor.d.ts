declare module 'jsoneditor';
