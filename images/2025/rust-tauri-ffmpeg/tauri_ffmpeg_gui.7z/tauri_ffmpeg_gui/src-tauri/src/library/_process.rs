use std::{ 
    process::Command,
    ptr::null_mut,
};

/// 結合成完整的指令 (含各系統的啟動shell / cmd)
/// # 參數
/// - `command`: 主要指令
/// # 回傳
/// - `Command`: 回傳完整的指令
pub fn command_combine(command: &str) -> Command {

    if cfg!(windows) {
        let mut cmd = Command::new("cmd");
        cmd.arg("/C");
        cmd.arg(command);
        cmd
    } else {
        let mut cmd = Command::new("sh");
        cmd.arg("-c");
        cmd.arg(command);
        cmd
    }
}

/// 終止正在運行的 ffmpeg 子進程
/// # 參數
/// - `pid` - 子進程的 PID
pub fn kill_process(pid: u32) {
    #[cfg(unix)] { kill_unix_process(pid as i32); }
    #[cfg(windows)] { kill_windows_process(pid); }
}

/// 終止正在運行的 ffmpeg 子進程（Unix）
/// # 參數
/// - `pid` - 子進程的 PID
/// # 注意
/// - 這個函數使用 `nix` crate 的 `kill` 函tion來終止進程。
/// - 確保在使用此函數前，已經導入了 `nix` crate。
#[allow(dead_code)]
fn kill_unix_process(pid: i32) {
    use nix::sys::signal::{kill, Signal};
    use nix::unistd::Pid;
    let _ = kill(Pid::from_raw(pid as i32), Signal::SIGKILL);
}

/// 終止正在運行的 ffmpeg 子進程（Windows）
/// # 參數
/// - `pid` - 子進程的 PID
/// # 注意
/// - 這個函數使用 `OpenProcess` 和 `TerminateProcess` API
///   來終止進程。
/// - 確保在使用此函數前，已經導入了 `windows-sys` crate。
#[allow(dead_code)]
fn kill_windows_process(pid: u32) {
    use windows_sys::Win32::System::Threading::PROCESS_TERMINATE;
    use windows_sys::Win32::System::Threading::{OpenProcess, TerminateProcess};
    unsafe {
        let handle = OpenProcess(PROCESS_TERMINATE, 0, pid);
        if handle != null_mut() {
            let _ = TerminateProcess(handle, 1);
        }
    }
}