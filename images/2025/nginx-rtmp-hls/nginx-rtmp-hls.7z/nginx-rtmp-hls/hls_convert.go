package main

import "os/exec"

func main() {
	convertToHLS("input.mp4", "./hls/")
}

func convertToHLS(inputFile, outputPath string) error {
	cmd := exec.Command("ffmpeg",
		"-i", inputFile,
		"-profile:v", "baseline",
		"-level", "3.0",
		"-start_number", "0",
		"-hls_time", "10",
		"-s", "640x480",
		"-hls_list_size", "0",
		"-f", "hls",
		outputPath+"/playlist.m3u8")

	return cmd.Run()
}

