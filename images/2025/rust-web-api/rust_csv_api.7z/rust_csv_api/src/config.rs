pub const DEFAULT_PORT: u16 = 8080;
pub const LOCALHOST: &str = "127.0.0.1";
pub const CSV_FOLDER_PATH: &str = "document";
pub const UPLOAD_FOLDER_PATH: &str = "upload";
