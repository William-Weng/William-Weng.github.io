use std::cell::Cell;
use std::fs::File;
use std::io::{Error};
use std::fmt::Debug;

use colored::Colorize;
use actix_web::http::StatusCode;
use actix_web::{HttpRequest};
use chrono::{Local};
use csv::Reader;
use serde::de::DeserializeOwned;

use crate::constant::{HttpMethod};

/// 印出日誌訊息
/// ## 參數
/// - `request`: `HttpRequest` 物件
/// - `status_code`: `Cell<StatusCode>` 狀態碼
/// - `method`: `HttpMethod` HTTP 方法
/// ## 回傳
/// - `Result<(), Error>`
pub fn log_message(request: &HttpRequest, status_code: &Cell<StatusCode>, method: HttpMethod) -> String {

    let connection_info = request.connection_info().clone();
    let client_ip = connection_info.peer_addr().unwrap_or("unknown");
    let request_url = request.uri().to_string();

    let status = match status_code.get() {
        code if (500..600).contains(&code.as_u16()) => status_code.get().to_string().blue(),
        StatusCode::OK => status_code.get().to_string().green(),
        _ => status_code.get().to_string().red(),
    };

    // 置中對齊，最少 5 字
    let fix_method = format!("{:^5}", method.as_str());

    format!(
        "{ip} - [{date}] {method} {url}, {status}",
        ip = client_ip.bold(),
        date = Local::now().format("%d/%b/%Y %H:%M:%S"),
        url = request_url.yellow(),
        method = fix_method.on_custom_color(method.on_custom_color()).black(),
        status = status,
    )
}

/// 解析 CSV 檔案並返回記錄
/// ## 參數
/// - `file_path`: CSV 檔案的路徑
/// ## 回傳
/// - `Result<Vec<T>, Error>` 解析後的記錄向量或錯誤
pub fn parse_csv_file<T>(file_path: String) -> Result<Vec<T>, Error> where T: DeserializeOwned + Debug {

    let mut records: Vec<T> = Vec::new();

    let opened_file = match File::open(file_path) {
        Err(error) => return Err(error),
        Ok(file) => file,
    };

    let mut reader = Reader::from_reader(opened_file);

    for result in reader.deserialize() {
        match result {
            Err(error) => return Err(error.into()),
            Ok(record) => { records.push(record) }
        }
    }

    Ok(records)
}