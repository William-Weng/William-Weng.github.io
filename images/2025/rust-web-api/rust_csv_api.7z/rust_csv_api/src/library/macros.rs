/// 定義一個巨集來簡化打印位置資訊 (要有colored套件)
#[macro_export]
macro_rules! ww_print {
    ($message:expr) => {
        println!("\n[{file} - {line}]\n{message}", 
            file = file!().green().bold(),
            line = format!("line.{}", line!().to_string()).yellow().bold(),
            message = $message
        )
    };
}

/*
常見的巨集指定義符：

macro_rules! example {
    // expr：任何表達式
    ($var:expr) => { /* ... */ };

    // ident：識別符/變數名稱
    ($var:ident) => { /* ... */ };

    // ty：型別
    ($var:ty) => { /* ... */ };

    // pat：模式 - Rust 模式匹配語法
    ($var:pat) => { /* ... */ };

    // stmt：陳述式
    ($var:stmt) => { /* ... */ };

    // block：程式碼區塊
    ($var:block) => { /* ... */ };
}

// 使用 expr (表達式)
ww_print!("Hello");           // 字串字面值
ww_print!(format!("{}", 42)); // 函式呼叫
ww_print!(1 + 2);            // 數學運算

// 如果是 ident，只能接受識別符
macro_rules! print_var_name {
    ($var:ident) => {
        println!("變數名稱是: {}", stringify!($var));
    };
}

print_var_name!(hello);  // 正確
print_var_name!("hello"); // 錯誤！因為不是識別符
*/