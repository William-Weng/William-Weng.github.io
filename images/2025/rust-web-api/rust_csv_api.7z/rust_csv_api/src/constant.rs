use colored::{Colorize, CustomColor};
use crate::ww_print;

#[derive(Debug)]
#[allow(dead_code)]
pub enum CustomError {
    EmptyString,
    ParseStringError,
    InvalidType(String),
    FileNotFound(String),
    UnknownError,
}

impl std::fmt::Display for CustomError {

    fn fmt(&self, format: &mut std::fmt::Formatter) -> std::fmt::Result {
        match self {
            CustomError::InvalidType(_type) => write!(format, "無效的檔案類型: {}", _type),
            CustomError::EmptyString => write!(format, "檔案類型不能為空"),
            CustomError::UnknownError => write!(format, "未知錯誤"),
            CustomError::ParseStringError => write!(format, "字串解析錯誤"),
            CustomError::FileNotFound(path) => write!(format, "檔案未找到: {}", path),
        }
    }
}

#[derive(Debug)]
#[allow(dead_code)]
pub enum HttpMethod {
    Get,
    Post,
}

impl HttpMethod {

    /// 轉型成字串 => as &str
    /// ## 回傳
    /// - `&str`
    pub fn as_str(&self) -> &str {
        match self {
            HttpMethod::Get => "Get",
            HttpMethod::Post => "Post",
        }
    }

    /// 設定背景顏色 with colored
    /// ## 回傳
    /// - `CustomColor`
    pub fn on_custom_color(&self) -> CustomColor {
        match self {
            HttpMethod::Get => CustomColor::new(24, 226, 18),
            HttpMethod::Post => CustomColor::new(255, 250, 250),
        }
    }
}

#[derive(Debug)]
#[allow(dead_code)]
pub enum CsvFileType {
    Linux,
    CrossPlatform,
}

impl CsvFileType {

    /// 轉型成字串 => as &str
    /// ## 回傳
    /// - `&str`
    pub fn as_str(&self) -> &str {
        match self {
            CsvFileType::Linux => "Linux.csv",
            CsvFileType::CrossPlatform => "CrossPlatform.csv",
        }
    }
}

impl std::str::FromStr for CsvFileType {

    type Err = CustomError;

    /// 轉型成字串 (實作FromStr) => (CsvFileType::from_str() / <filename>.parse()) => as &str
    /// ## 回傳
    /// - `&str`
    fn from_str(str: &str) -> Result<Self, Self::Err> {

        ww_print!(format!("輸入的文字為: {}", str));

        match str.to_lowercase().as_str() {
            "linux" => Ok(CsvFileType::Linux),
            "crossplatform" => Ok(CsvFileType::CrossPlatform),
            _ => Err(CustomError::InvalidType(str.to_string())),
        }
    }
}