use std::collections::HashMap;
use std::io::{Error};

use actix_web::{App, HttpRequest, HttpServer, Responder, web};
use actix_web::{get, post};
use actix_multipart::Multipart;
use colored::Colorize;
use local_ip_address::local_ip;

mod config;
mod constant;
mod library;
mod model;
mod service;

use crate::config::*;
use crate::model::Params;

use crate::service::csv_service as _service_;

/// 第一個GET範例 => /first
#[get("/first")]
async fn get_first_action(request: HttpRequest) -> impl Responder {
    _service_::get_first_action(request)
}
/// 取得Query參數範例 => /query?id=987987&name=William
#[get("/query")]
async fn get_query_action(request: HttpRequest, query: web::Query<Params>) -> impl Responder {
    _service_::get_query_action(request, query)
}

/// 取得Body參數範例 => /json + {"id":987987,"name":"William"}
#[post("/json")]
async fn post_json_action(request: HttpRequest, input: web::Json<Params>) -> impl Responder {
    _service_::post_json_action(request, input)
}

/// 動態路由 => /user/3939889/William
#[post("/user/{id}/{name}")]
async fn post_router_action(
    request: HttpRequest,
    path: web::Path<(String, String)>,
) -> impl Responder {
    _service_::post_router_action(request, path)
}

/// 取得動態Query參數範例 => /dynamic?name=william&ago=18
#[post("/dynamic")]
async fn dynamic_query(
    request: HttpRequest,
    query: web::Query<HashMap<String, String>>,
) -> impl Responder {
    _service_::dynamic_query(request, query)
}

/// 讀取CSV檔案內容 => /csv/<filename>
#[post("/csv/{filename}")]
async fn csv_action(request: HttpRequest, path: web::Path<String>) -> impl Responder {
    _service_::read_csv_action(request, path)
}

/// 檔案上傳 + 儲存檔案內容 => /upload + {"<key>: <file>"}
#[post("/upload")]
async fn upload_action(request: HttpRequest, payload: Multipart) -> impl Responder {
    _service_::multi_upload_action(request, payload).await
}

/// 檔案下載 => /download/{filename}
#[get("/download/{filename}")]
async fn download_action(request: HttpRequest, path: web::Path<String>) -> impl Responder {
    _service_::download_file(request, path).await
}

/// 註冊API服務 => .service()
/// ## 回傳
/// - `Result<(), Error>`
async fn register_service() -> Result<(), Error> {
    let current_ip = local_ip().unwrap_or_else(|_| LOCALHOST.parse().unwrap());

    ww_print!(format!("Starting server at {localhost}:{port}\nStarting server at {ip}:{port}", ip = current_ip, port = DEFAULT_PORT, localhost = LOCALHOST));

    HttpServer::new(|| {
        App::new()
            .service(get_first_action)
            .service(get_query_action)
            .service(post_json_action)
            .service(dynamic_query)
            .service(post_router_action)
            .service(csv_action)
            .service(upload_action)
            .service(download_action)
    })
    .bind(format!("{}:{}", current_ip, DEFAULT_PORT))?
    .bind(format!("{}:{}", LOCALHOST, DEFAULT_PORT))?
    .run()
    .await
}

#[actix_web::main]
async fn main() -> Result<(), Error> {
    register_service().await
}
