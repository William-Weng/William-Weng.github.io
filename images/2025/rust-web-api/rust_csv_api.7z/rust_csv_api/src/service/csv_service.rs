use std::cell::Cell;
use std::collections::HashMap;
use std::str::FromStr;

use actix_web::http::StatusCode;
use actix_web::{HttpRequest, HttpResponse, Responder, web};
use chrono::{Utc};
use colored::Colorize;
use serde_json::{Value};

use crate::library::utility::{log_message, parse_csv_file};
use crate::model::*;
use crate::config;
use crate::constant::{HttpMethod, CsvFileType};
use crate::ww_print;

/// 第一個GET範例 => /first
/// ## 回傳
/// - `Responder`
pub fn get_first_action(request: HttpRequest) -> impl Responder {

    let status_code = Cell::new(StatusCode::OK);
    let now = Utc::now();

    let _defer = Defer::new(|| {
        ww_print!(log_message(&request, &status_code, HttpMethod::Get));
    });
    
    let response = Message {
        message: "安安你好嗎？".to_string(),
        timestamp: now.timestamp_millis(),
        date: now.to_rfc3339(),
    };

    web::Json(response)
}

/// 取得Query參數範例 => /query?id=987987&name=William
/// - `id`: 可選的使用者ID
/// - `name`: 可選的使用者名稱
/// ## 回傳
/// - `Responder`
pub fn get_query_action(request: HttpRequest, query: web::Query<Params>) -> impl Responder {

    let status_code = Cell::new(StatusCode::OK);
    let now = Utc::now();

    let _defer = Defer::new(|| {
        ww_print!(log_message(&request, &status_code, HttpMethod::Get));
    });

    let message = match (&query.name, query.id) {
        (Some(name), Some(id)) => format!("Hello, {} (ID: {})!", name, id),
        (Some(name), None) => format!("Hello, {}!", name),
        (None, Some(id)) => format!("Hello, User {}!", id),
        (None, None) => String::from("Hello, World!"),
    };

    let response = Message {
        message: message.to_string(),
        timestamp: now.timestamp_millis(),
        date: now.to_rfc3339(),
    };

    web::Json(response)
}

/// 取得Body參數範例 => /json + {"id":987987,"name":"William"}
/// - `id`: 可選的使用者ID
/// - `name`: 可選的使用者名稱
/// ## 回傳
/// - `Responder`
pub fn post_json_action(request: HttpRequest, input: web::Json<Params>) -> impl Responder {

    let status_code = Cell::new(StatusCode::OK);
    let now = Utc::now();

    let _defer = Defer::new(|| {
        ww_print!(log_message(&request, &status_code, HttpMethod::Post));
    });

    let message = match (&input.name, input.id) {
        (Some(name), Some(id)) => format!("Hello, {} (ID: {})!", name, id),
        (Some(name), None) => format!("Hello, {}!", name),
        (None, Some(id)) => format!("Hello, User {}!", id),
        (None, None) => String::from("Hello, World!"),
    };

    let json = format!(
        r#"{{ 
            "message": "{}", 
            "timestamp": {}, 
            "date": "{}" 
        }}"#,
        message,
        now.timestamp_millis(),
        now.to_rfc3339()
    );

    let parsed: Value = serde_json::from_str(&json).unwrap();
    web::Json(parsed).customize().with_status(status_code.get())
}

/// 動態路由 => /user/3939889/William
/// - `id`: 使用者ID
/// - `name`: 使用者名稱
pub fn post_router_action(request: HttpRequest, path: web::Path<(String, String)>) -> impl Responder {

    let status_code = Cell::new(StatusCode::OK);
    let _defer = Defer::new(|| {
        ww_print!(log_message(&request, &status_code, HttpMethod::Post));
    });

    let (id, _name) = path.into_inner();

    let response = serde_json::json!({
        "id": id,
        "message": "更新成功",
        "timestamp": Utc::now().timestamp_millis()
    });

    web::Json(response).customize().with_status(status_code.get())
}

/// 取得動態Query參數範例 => /dynamic?name=william&ago=18
/// - `name`: 使用者名稱
/// - `ago`: 使用者年齡
pub fn dynamic_query(request: HttpRequest, query: web::Query<HashMap<String, String>>) -> impl Responder {

    let status_code = Cell::new(StatusCode::OK);
    let _defer = Defer::new(|| {
        ww_print!(log_message(&request, &status_code, HttpMethod::Post));
    });

    for (key, value) in query.iter() {
        println!("{}: {}", key, value);
    }
    
    HttpResponse::Ok().json(query.into_inner())
}

/// 讀取CSV檔案內容 => /csv/<filename>
/// - `filename`: CSV檔案名稱
/// ## 回傳
/// - `Responder`
pub fn read_csv_action(request: HttpRequest, path: web::Path<String>) -> impl Responder {

    let status_code = Cell::new(StatusCode::NOT_FOUND);
    let _defer = Defer::new(|| {
        ww_print!(log_message(&request, &status_code, HttpMethod::Post));
    });

    let filename = path.into_inner();
    // let file_type: CsvFileType = match filename.parse() {
    let file_type: CsvFileType = match CsvFileType::from_str(filename.as_str()) {
        Ok(_type) => _type,
        Err(error) => {
            ww_print!(format!("錯誤: {}. 預設為: Linux.csv", error));
            CsvFileType::Linux
        }
    };

    let file_path: String = format!("{}/{}", config::CSV_FOLDER_PATH, file_type.as_str());
    let records: Vec<CsvRecord> = match parse_csv_file(file_path) {
        Err(error) => {
            status_code.set(StatusCode::BAD_REQUEST);
            return web::Json(serde_json::json!({ "error": error.to_string() })).customize().with_status(status_code.get());
        }
        Ok(records) => records,
    };

    let response = serde_json::json!({ "result": records });
    status_code.set(StatusCode::OK);

    web::Json(serde_json::json!(response)).customize().with_status(status_code.get())
}