use serde::{Serialize, Deserialize};
use serde::de::Deserializer;

#[derive(Serialize)]
pub struct Message {
    pub message: String,
    pub timestamp: i64,
    pub date: String,
}

#[derive(Deserialize)]
pub struct Params {
    pub id: Option<i32>,
    pub name: Option<String>,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct CsvRecord {
    pub name: String,
    pub notes: String,
    pub url: String,
    pub level: u8,
    
    #[serde(skip_serializing_if = "Option::is_none")]
    pub example: Option<String>,

    #[serde(deserialize_with = "deserialize_platform")]
    #[serde(default)]
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub platform: Vec<String>,
}

/// 把字串轉換成平台列表
/// 例如: "Windows, Linux, macOS" 會轉換成 ["Windows", "Linux", "macOS"]
fn deserialize_platform<'de, D>(deserializer: D) -> Result<Vec<String>, D::Error> where D: Deserializer<'de> {
    let str = String::deserialize(deserializer)?;
    Ok(str.split(',').map(|str| str.trim().to_string()).collect())
}

pub struct Defer<F: FnMut()> {
    closure: F,
}

impl<F: FnMut()> Defer<F> {
    pub fn new(closure: F) -> Self {
        Self { closure }
    }
}

impl<F: FnMut()> Drop for Defer<F> {
    fn drop(&mut self) {
        (self.closure)();
    }
}
