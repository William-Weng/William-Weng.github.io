# Rust format! 巨集使用指南

## 1. 基本字串格式化
```rust
let name = "Alice";
let age = 25;
let message = format!("名字: {}, 年齡: {}", name, age);
```

## 2. 命名參數
```rust
let message = format!(
    "名字: {name}, 年齡: {age}",
    name = "Bob",
    age = 30
);
```

## 3. 數字格式化
### 二進制
```rust
let binary = format!("{:b}", 42);    // "101010"
```

### 十六進制
```rust
let hex = format!("{:x}", 42);       // "2a"
let hex_upper = format!("{:X}", 42); // "2A"
```

### 八進制
```rust
let octal = format!("{:o}", 42);     // "52"
```

### 科學記號
```rust
let scientific = format!("{:e}", 1234.5678); // "1.2345678e3"
```

## 4. 對齊和填充
```rust
// 靠左對齊，寬度為 5
let left = format!("{:<5}", "hi");   // "hi   "

// 靠右對齊，寬度為 5
let right = format!("{:>5}", "hi");  // "   hi"

// 置中對齊，寬度為 5
let center = format!("{:^5}", "hi"); // " hi  "

// 使用 0 填充
let zero = format!("{:0>5}", "123"); // "00123"
```

## 5. 精確度控制
```rust
// 浮點數精確度
let pi = format!("{:.2}", 3.1415926); // "3.14"

// 字串截取
let text = format!("{:.3}", "abcdef"); // "abc"
```

## 6. Debug 格式化
```rust
#[derive(Debug)]
struct Point { x: i32, y: i32 }
let point = Point { x: 1, y: 2 };

// 一般 debug 輸出
let debug = format!("{:?}", point);   // Point { x: 1, y: 2 }

// 美化輸出
let pretty = format!("{:#?}", point);
```

## 7. 動態寬度和精確度
```rust
let width = 5;
let precision = 2;
let num = 3.1415926;
let formatted = format!(
    "{:width$.precision$}", 
    num, 
    width=8, 
    precision=2
);
```

## 8. 指定型別
```rust
let num = 42;
let hex = format!("{num:x}");     // 十六進制
let binary = format!("{num:b}");  // 二進制
```

## 組合使用範例
```rust
let complex = format!(
    "{:0>width$b}",  // 二進制，靠右對齊，用 0 填充
    42,
    width = 8
);  // "00101010"
```