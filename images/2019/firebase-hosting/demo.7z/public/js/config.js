var firebaseConfig = {
  apiKey: "AIzaSyCXLgMifVyVgn2hcED--YCYEE5pYcSy03I",
  authDomain: "ebook-72a9f.firebaseapp.com",
  databaseURL: "https://ebook-72a9f.firebaseio.com",
  projectId: "ebook-72a9f",
  storageBucket: "ebook-72a9f.appspot.com",
  messagingSenderId: "82422951394",
  appId: "1:82422951394:web:0fa84260b5ed04b8635dbb"
}

firebase.initializeApp(firebaseConfig)