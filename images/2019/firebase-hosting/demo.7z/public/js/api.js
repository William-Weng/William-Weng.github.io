const tableID = 'books'
const path = '/eBook'
const type = 'value'

firebase.database().ref(path).on(type, snapshot => {

    const bookInfos = snapshot.val()

    let tableInfo = '<tr><th>ISBN</th><th>書名</th></tr>'

    Object.keys(bookInfos).map((isbn) => {
        const info = bookInfos[isbn]
        tableInfo += `<tr><td>${isbn}</td><td>${info.name}</td></tr>`
    })

    document.getElementById(tableID).innerHTML = tableInfo
})