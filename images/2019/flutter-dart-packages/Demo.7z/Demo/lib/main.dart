// main.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
// This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '使用第三方套件',
      home: new Scaffold(
        appBar: new AppBar(
          title: new Text('網頁'),
        ),
        body: new Center(
          child: new RaisedButton(
            onPressed: () {
              const url = 'https://google.com';
              launch(url);
            },
            child: new Text('https://google.com'),
          ),
        ),
      ),
    );
  }
}
