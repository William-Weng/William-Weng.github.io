// [TypeScript Tutorial - HowToDoInJava](https://howtodoinjava.com/typescript/typescript-tutorial/)
// [TypeScript 基本類型](https://kim85326.github.io/2018/10/04/TypeScript-基本類型/)

import * as functions from 'firebase-functions'
import * as admin from 'firebase-admin'

admin.initializeApp()

const eventType: admin.database.EventType = 'value'

// MARK: - 輸出的Function名稱 (給Firebase Functions看的)
module.exports = {
    tsHelloWorld: helloWorld(),
    tsBookList: bookList(),
    tsBookListOrderByChild: bookListOrderByChild(),
    tsBookListOrderByKeyOfRange: bookListOrderByKeyOfRange(),
}

// MARK: - 主程式
/// 印出中文字 (https://<host>/tsHelloWorld)
function helloWorld(): functions.HttpsFunction {
    return functions.https.onRequest((request, response) => {
        response.send(getHelloWorld())
    })
}

/// 取得全部的書籍資訊 (https://<host>/tsBookList)
function bookList(): functions.HttpsFunction {
    return functions.https.onRequest((request, response) => {
        getBookList('eBook', (snapshot) => { response.send(snapshot) })
    })
}

/// 取得排序後的書籍資訊 (https://<host>/tsBookListOrderByChild?child=name)
function bookListOrderByChild() {
    return functions.https.onRequest((request, response) => {
        getBookListOrderByChild('eBook', request, (snapshot) => { response.send(snapshot) })
    })
}

/// 取得排序後在範圍內的書籍資訊 (https://<host>/tsBookListOrderByKeyOfRange?child=order&start=2&end=4)
function bookListOrderByKeyOfRange() {
    return functions.https.onRequest((request, response) => {
        getBookListOrderByKeyOfRange('eBook', request, (snapshot) => { response.send(snapshot) })
    })
}

// MARK: - 主工具
/// 取得中文字
function getHelloWorld(): Object {
    return ({ helloWorld: "哈囉你好嗎，衷心感謝，珍重再見，期待再相逢" })
}

/// 取得全部的書籍資訊
function getBookList(path: string, callback: (snapshot: admin.database.DataSnapshot) => void) {

    admin.database().ref(path).once(eventType).then((snapshot) => {
        callback(snapshot)
    }).catch((reason) =>
        console.log(reason)
    )
}

/// 根據子Key排序後，取得全部的書籍資訊
function getBookListOrderByChild(path: string, request: functions.https.Request, callback: (snapshot: any[]) => void) {
    
    _getBookListOrderByChild(path, request, (snapshot) => {
        callback(snapshotToArray(snapshot))
    })
}

/// 根據子Key排序後，取得該範圍內的書籍資訊
function getBookListOrderByKeyOfRange(path: string, request: functions.https.Request, callback: (snapshot: any[]) => void) {
    
    _getBookListOrderByKeyOfRange(path, request, (snapshot) => {
        callback(snapshotToArray(snapshot))
    })
}

// MARK: - 小工具
/// 根據子Key排序後，取得全部的書籍資訊
function _getBookListOrderByChild(path: string, request: functions.https.Request, callback: (snapshot: admin.database.DataSnapshot) => void) {
    
    const child = request.query.child as string

    admin.database().ref(path).orderByChild(child).once(eventType).then((snapshot) => {
        callback(snapshot)
    }).catch((error) =>
        console.log(error)
    )
}

/// 根據子Key排序後，取得該範圍內的書籍資訊
function _getBookListOrderByKeyOfRange(path: string, request: functions.https.Request, callback: (snapshot: admin.database.DataSnapshot) => void) {

    const parameter = {
        child: request.query.child as string,
        start: parseInt(request.query.start),
        end: parseInt(request.query.end),
    }

    admin.database().ref(path).orderByChild(parameter.child).startAt(parameter.start).endAt(parameter.end).once(eventType).then((snapshot) => {
        callback(snapshot)
    }).catch((error) =>
        console.log(error)
    )
}

/// 將snapshot => Array
function snapshotToArray(snapshot: admin.database.DataSnapshot): any[] {
    
    const items: any[] = []

    snapshot.forEach((item) => {
        const dict = item.val()
        dict.identify = item.key
        items.push(dict)
    })

    return items
}