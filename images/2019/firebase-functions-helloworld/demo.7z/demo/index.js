// [JavaScript 陣列處理方法 [filter(), find(), forEach(), map(), every(), some(), reduce()] | 六角學院](https://www.hexschool.com/2017/09/01/2017-09-01-javascript-for/#Array-prototype-forEach)

const functions = require('firebase-functions');
const admin = require("firebase-admin")

admin.initializeApp()

// MARK: - 輸出的Function名稱 (給Firebase Functions看的)
module.exports = {
    helloWorld: functions.https.onRequest((request, response) => {
        response.send(getHelloWorld())
    }),
    bookList: functions.https.onRequest((request, response) => {
        getBookList('eBook', (snapshot) => { response.send(snapshot) })
    }),
    bookListOrderByChild: functions.https.onRequest((request, response) => {
        getBookListOrderByChild('eBook', request, (array) => { response.send(array) })
    }),
    bookListOrderByKeyOfRange: functions.https.onRequest((request, response) => {
        getBookListOrderByKeyOfRange('eBook', request, (array) => { response.send(array) })
    }),
}

// MARK: - 主工具
/// helloWorld() => 印出中文字 (https://<host>/helloWorld)
function getHelloWorld() {
    return ("哈囉你好嗎，衷心感謝，珍重再見，期待再相逢")
}

/// 取得全部的書籍資訊 (https://<host>/bookList)
function getBookList(path, callback) {

    let readType = 'value'

    admin.database().ref(path).once(readType, (snapshot) => {
        callback(snapshot)
    })
}

/// 根據子Key排序後，取得全部的書籍資訊 => Array (https://<host>/bookListOrderByChild?child=name)
function getBookListOrderByChild(path, request, callback) {
    
    _getBookListOrderByChild(path, request, (snapshot) => {
        let items = snapshotToArray(snapshot)
        callback(items)
    })
}

/// 根據子Key排序後，取得該範圍內的書籍資訊 => Array (https://<host>/bookListOrderByKeyOfRange?child=order&start=2&end=4)
function getBookListOrderByKeyOfRange(path, request, callback) {
    
    _getBookListOrderByKeyOfRange(path, request, (snapshot) => {
        let items = snapshotToArray(snapshot)
        callback(items)
    })
}

// MARK: - 小工具
/// 根據子Key排序後，取得全部的書籍資訊
function _getBookListOrderByChild(path, request, callback) {

    let readType = 'value'
    let child = request.query.child

    admin.database().ref(path).orderByChild(child).once(readType, (snapshot) => {
        callback(snapshot)
    })
}

/// 根據子Key排序後，取得該範圍內的書籍資訊
function _getBookListOrderByKeyOfRange(path, request, callback) {

    let readType = 'value'
    let child = request.query.child
    let start = parseInt(request.query.start)
    let end = parseInt(request.query.end)

    admin.database().ref(path).orderByChild(child).startAt(start).endAt(end).once(readType, (snapshot) => {
        callback(snapshot)
    })
}

/// 將snapshot => Array
function snapshotToArray(snapshot) {
    
    let items = []
    let dict = snapshot.val()

    for (let key in dict) {
        let _item = dict[key]
        _item['identify'] = key
        // _item.identify = key
        items.push(_item)
    }

    return items
}