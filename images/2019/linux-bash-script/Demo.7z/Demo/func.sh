function my_print {
    echo "@my_print";
}

your_print () {
    echo "@your_print";
}

my_print;
your_print;