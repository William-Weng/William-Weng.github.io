#! /bin/bash
if [ ! $# -eq 3 ]; then
    echo "參數數量不是三個";
    exit;
fi

if [ $2 = "+" ]; then
    echo "相加 = $(($1+$3))";
elif [ $2 = "-" ]; then
    echo "相減 = $(($1-$3))";
else 
    echo "不能運算喲"
fi