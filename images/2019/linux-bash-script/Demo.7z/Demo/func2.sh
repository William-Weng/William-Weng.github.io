hello () {
    echo -e "hello, \$1 = $1, \$2 = $2";
}

isEqual () {
    if [ $1 -eq $2 ]; then
        return 0;
    fi

    return 1;
}

hello william go

isEqual 1 2
echo $?