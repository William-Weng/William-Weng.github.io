case "$1" in
    0)
        echo "Zero";;
    1)
        echo "First";;
    *)
        echo "Other";;
esac