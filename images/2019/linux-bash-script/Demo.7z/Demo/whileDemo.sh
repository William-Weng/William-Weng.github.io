while read line; do                                         # 一次讀取一行文字
    IFS=',';                                                # 設定分隔號為，
    read -a records <<< "$line";                            # 將line內容存入records中
    echo "${records[0]}, ${records[1]}, ${records[2]}" 
done < $1                                                   # 將檔名(參數1)當成輸入資料