(( index=10 ));
while (( index > 0 )); do
    echo "index = $index";
    (( index-- ));
done
