colors="red green blue"
select color in $colors; do
    case $color in
        "$quit")
            echo "bye"
            break;;
        *)
            echo "selected color is $color";;
    esac
done
