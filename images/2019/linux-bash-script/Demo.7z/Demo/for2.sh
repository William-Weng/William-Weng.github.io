for paramater in $*; do     # $* => 傳回的是String
    echo $paramater;
done

for paramater in $@; do     # $@ => 傳回的是Array
    echo $paramater;
done