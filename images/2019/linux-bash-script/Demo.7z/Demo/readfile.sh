IFS=$'\n';                  # IFS: 換行符號
for line in $(cat $1); do   # cat: 讀取文件內容
    echo $line;
done
