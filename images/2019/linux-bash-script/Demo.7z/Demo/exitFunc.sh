exit_func () {
    if [ $1 = 1 ]; then
        echo "exit in func";
        exit 1;
    fi
}

exit_func $1;
echo "exit in main";
exit 0;
