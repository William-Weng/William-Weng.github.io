for filename in *.sh; do
    echo $filename;
done
