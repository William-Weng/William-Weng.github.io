select filename in *; do
    echo "You select $filename, $REPLY";    # $REPLY: 保留字
    break;                                  # 中斷迴圈，不然會一直問 =
done
