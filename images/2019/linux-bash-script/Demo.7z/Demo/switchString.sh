case "$1" in
    william)
        echo "Hello $1";;
    jack)
        echo "Good morning, $1";;
    *)
        echo "How are you, $1";;
esac