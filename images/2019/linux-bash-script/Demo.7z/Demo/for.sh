for index in {10..1}; do
    echo $index;
done

datas="A B C D E";

for string in $datas; do
    echo $string;
done