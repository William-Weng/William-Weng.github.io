//
//  MyImageSDK.swift
//  MySwiftSDK
//
//  Created by William on 2019/5/6.
//  Copyright © 2019 William. All rights reserved.
//

import Foundation

public class ImageProcessor {
    
    var image: UIImage?
    lazy var context: CIContext = { return CIContext(options: nil) }()
    
    public init(image: UIImage?) {
        self.image = image
    }
    
    open func pixellated(scale:Int = 30) -> UIImage? {
        
        if image == nil { return nil }
        
        let filter = CIFilter(name: "CIPixellate")!
        let inputImage = CIImage(image: image!)

        filter.setValue(inputImage, forKey: kCIInputImageKey)
        filter.setValue(scale, forKey: kCIInputScaleKey)
        
        let fullPixellatedImage = filter.outputImage
        let cgImage = context.createCGImage(fullPixellatedImage!, from: fullPixellatedImage!.extent)
        
        return UIImage(cgImage: cgImage!)
    }
    
    open func blured(radius: Int = 40) -> UIImage? {
        
        if image == nil { return nil }
        
        let filter = CIFilter(name: "CIGaussianBlur")!
        let inputImage = CIImage(image: image!)

        filter.setValue(inputImage, forKey: kCIInputImageKey)
        filter.setValue(radius, forKey: kCIInputRadiusKey)

        let outputCIImage = filter.outputImage
        let rect = CGRect(origin: CGPoint.zero, size: image!.size)
        let cgImage = context.createCGImage(outputCIImage!, from: rect)

        return UIImage(cgImage: cgImage!)
    }
}
