//
//  MySwiftSDK.h
//  MySwiftSDK
//
//  Created by William on 2019/5/6.
//  Copyright © 2019 William. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MySwiftSDK.
FOUNDATION_EXPORT double MySwiftSDKVersionNumber;

//! Project version string for MySwiftSDK.
FOUNDATION_EXPORT const unsigned char MySwiftSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySwiftSDK/PublicHeader.h>


