//
//  ViewController.swift
//  SDK_Test
//
//  Created by William on 2019/5/6.
//  Copyright © 2019 William. All rights reserved.
//

import UIKit
import MySwiftSDK

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    var defaultImage = #imageLiteral(resourceName: "swift")
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func btn1Click(_ sender: AnyObject) {
        imageView.image = defaultImage
    }
    
    @IBAction func btn2Click(_ sender: AnyObject) {
        imageView.image = ImageProcessor(image: defaultImage).pixellated()
    }
    
    @IBAction func btn3Click(_ sender: AnyObject) {
        imageView.image = ImageProcessor(image: defaultImage).blured()
    }
}

