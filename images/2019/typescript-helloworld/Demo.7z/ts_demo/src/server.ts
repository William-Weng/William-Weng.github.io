import * as http from 'http'

http.get({
    hostname: 'localhost',
    port: 4000,
    path: '/',
    agent: false  // Create a new agent just for this one request
  }, (res) => {
    console.log(res);    
  });