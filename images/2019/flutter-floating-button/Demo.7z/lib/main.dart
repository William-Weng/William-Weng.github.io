// main.dart
import 'package:flutter/material.dart';

// 程式進入點 => void main() { return runApp(FloatingActionButtonDemoApp()); }
void main() => runApp(FloatingActionButtonDemoApp());

// Main Class => StatelessWidget (狀態不變的) => build() (建立Widget)
class FloatingActionButtonDemoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FloatingActionButton範例',
      theme: ThemeData(primarySwatch: Colors.blue,),        // theme: MaterialApp的佈景主題
      home: MyHomePage(title: 'FloatingActionButton範例'),
      debugShowCheckedModeBanner: false,                    // debugShowCheckedModeBanner: 讓右上角的Debug圖示消失
    );
  }
}

// Sub Class => StatefulWidget (狀態可變的) => createState() (狀態的回傳值)
class MyHomePage extends StatefulWidget {
  final String title;

  MyHomePage({Key key, this.title}) : super(key: key);      // MyHomePage(): 初始化語法

  @override
  _MyHomePageState createState() => _MyHomePageState();     // 箭頭語法: _MyHomePageState createState() { return _MyHomePageState(); }                              
}

// Sub Class => State (設定狀態) => setState(fn) (使用它來改變數值) => onPressed: _incrementCounter (函數名稱)
class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title),),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('看看你按了幾次：',),
            Text('$_counter',style: Theme.of(context).textTheme.display1,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(           // FloatingActionButton: 浮動按鈕
        onPressed: _incrementCounter,                       // 按下觸發的方式名稱: void _incrementCounter()
        tooltip: '加1加1',                                   // 按住按鈕時出現的提示字
        child: Icon(Icons.add),
      ),
    );
  }

  // 按一下就加1
  void _incrementCounter() {
    setState(() { _counter+=1; });
  }
}
