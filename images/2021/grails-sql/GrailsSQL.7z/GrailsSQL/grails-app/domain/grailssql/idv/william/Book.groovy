package grailssql.idv.william

class Book {

    static constraints = {
        isbn13(size: 13, nullable: false, unique: true) // (13碼 / 不得為空值 / 是唯一值)
        title(nullable: false)
        releaseDate(nullable: false)
    }

    Long isbn13
    String title
    Date releaseDate
}
