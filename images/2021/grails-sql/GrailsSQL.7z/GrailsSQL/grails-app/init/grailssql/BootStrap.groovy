package grailssql

import java.awt.print.Book

class BootStrap {

    def init = { servletContext ->
    }

    def destroy = {
    }

    private def appendBook() {
        def book = new Book()
    }
}
