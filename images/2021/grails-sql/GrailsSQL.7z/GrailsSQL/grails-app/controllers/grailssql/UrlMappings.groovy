package grailssql

class UrlMappings {

    static mappings = {
        "/$controller/$action?/$id?(.$format)?"{
            constraints {
                // apply constraints here
            }
        }

        "/eBook/"(controller: 'book', action: 'save', method: 'GET')
        "/eBook/$id?"(controller: 'book', action: 'update', method: 'POST')
        "/eBook/$id?"(controller: 'book', action: 'update', method: 'PUT')
        "/eBook/$id?"(controller: 'book', action: 'delete', method: 'DELETE')

        "/eBook/new/"(controller: 'book', action: 'addBook', method: 'POST')
        "/eBook/criteria/"(controller: 'book', action: 'criteria', method: 'POST')

        "/eBook/hql/"(controller: 'book', action: 'hql', method: 'POST')
        "/eBook/sql/"(controller: 'book', action: 'sql', method: 'POST')

        "/"(view:"/index")
        "500"(view:'/error')
        "404"(view:'/notFound')
    }
}
