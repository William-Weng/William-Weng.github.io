package grailssql

import grails.converters.JSON
import grails.io.IOUtils
import grailssql.idv.william.Book
import groovy.sql.Sql

class BookController {

    def index() {

        // 讀取application.yml設定檔
        def applicationYml = this.grailsApplication.config
        def server = applicationYml.environments.development.server as HashMap<String, String>
        render("${server}")

        def resourceClassPath = 'classPath:resources/demo.txt'
        def resource = this.grailsApplication.mainContext.getResource(resourceClassPath)
        def fileString = IOUtils.toString(resource.inputStream)

        println(fileString)
    }

    def addBook() {

        def json = this.request.getJSON()

        def isbn13 = json['isbn13'] as Long
        def title = json['title'] as String
        def releaseDate = json['releaseDate'] as String

        def book = new Book()

        book.isbn13 = isbn13
        book.title = title
        book.releaseDate = new Date(releaseDate)

        def result = book.save(flash: true)

        if (result == null) { render([result: false] as JSON); return }

        render([result: true] as JSON);
    }

    def save() { render "新增" }
    def update(Long id) { render "修改 ${id}"  }
    def delete(Long id) { render "刪除 ${id}" }
    def show(Long id) { render "查詢 ${id}" }

    def criteria() {

        def books = Book.createCriteria().list {

            like("title", "誰搬走了%")
            and {
                between("isbn13", 9789578038090, 9789578038099)
            }
            maxResults(10)
            order("isbn13", "desc")
        }

        respond([books: books])
    }

    def hql() {

        def hqlQueryString = 'from Book';
        def books = Book.findAll(hqlQueryString)

        respond([books: books])
    }

    def sql() {

        def connection = Sql.newInstance(
                    "jdbc:mysql://localhost/eBook",
                    "root",
                    "12345678",
                    "com.mysql.cj.jdbc.Driver"
                )

        def queryString = 'select * from book'

        ArrayList<String> result = []

        connection.eachRow(queryString) {resultSet ->
            result.push(resultSet[2])
        }

        render([result: result] as JSON)
    }
}
