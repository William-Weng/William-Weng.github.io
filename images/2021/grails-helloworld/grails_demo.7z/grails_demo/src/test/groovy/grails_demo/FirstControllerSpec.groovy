package grails_demo

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class FirstControllerSpec extends Specification implements ControllerUnitTest<FirstController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
