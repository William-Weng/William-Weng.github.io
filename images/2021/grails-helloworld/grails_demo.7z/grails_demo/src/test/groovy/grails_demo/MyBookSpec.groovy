package grails_demo

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class MyBookSpec extends Specification implements DomainUnitTest<MyBook> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
