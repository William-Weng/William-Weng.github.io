package idv.william

import grails.artefact.Controller
import java.text.SimpleDateFormat

// MARK: - 小工具
final class Utility {

    // MARK: - 網頁相關
    /// 取得網址上的queryString
    def queryString(String key, Controller self) {
        def queryString = self.getParams()
        return queryString[key]
    }

    /// ["2021-01-01 01:23:45" => 1577836800](https://timestamp.online/)
    def dateStringToTimestamp(String dateString, Enumeration.DateFormat pattern) {

        if (dateString == null || pattern == null) { return null }

        def format = new SimpleDateFormat(pattern.toString())
        def timestamp = format.parse(dateString).getTime() / 1000

        return timestamp
    }

    /// [2021-01-01 01:23:45 => 1577836800](https://timestamp.online/)
    def dateToTimestamp(Date date, Enumeration.DateFormat pattern) {

        if (date == null || pattern == null) { return null }

        def dateString = this.dateToString(date, pattern)
        def timestamp = this.dateStringToTimestamp(dateString, pattern)

        return timestamp
    }

    /// "2020-01-01" => 2021-01-01 01:23:45
    def stringToDate(String dateString, Enumeration.DateFormat pattern) {

        if (dateString == null || pattern == null) { return null }

        def format = new SimpleDateFormat(pattern.toString())
        def date = format.parse(dateString)

        return date
    }

    /// 2021-01-01 01:23:45 => "2021-01-01"
    def dateToString(Date date, Enumeration.DateFormat pattern) {

        if (date == null || pattern == null) { return null }

        def format = new SimpleDateFormat(pattern.toString())
        def dateString = format.format(date)

        return dateString
    }
}