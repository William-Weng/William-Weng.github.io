package idv.william

/// MARK: - 常用列舉
final class Enumeration {

    /// [日期格式](http://www.unicode.org/reports/tr35/tr35-31/tr35-dates.html#Date_Format_Patterns)
    enum DateFormat {

        Short("yyyy-MM-dd"),
        Middle("yyyy-MM-dd HH:mm"),
        Long("yyyy-MM-dd HH:mm:ss"),
        Full("yyyy-MM-dd HH:mm:ss ZZZ")

        private final String value

        /// 利用文字尋找Enum
        static find(String value) { values().find { it.value == value } }

        /// 初始化
        DateFormat(String value) { this.value = value }

        /// override toString() => 取得內容文字的值
        String toString() { return value }
    }
}
