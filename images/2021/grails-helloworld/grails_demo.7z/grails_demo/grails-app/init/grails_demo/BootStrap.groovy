package grails_demo

class BootStrap {

    def init = { servletContext ->
        this.initSetting()
    }
    
    def destroy = {}

    private def initSetting() { TimeZone.setDefault(TimeZone.getTimeZone('UTC')) }
}
