package grails_demo

class MyBook {

    static constraints = {
        title unique: true
        releaseDate nullable: true
    }

    String title
    Date releaseDate
}
