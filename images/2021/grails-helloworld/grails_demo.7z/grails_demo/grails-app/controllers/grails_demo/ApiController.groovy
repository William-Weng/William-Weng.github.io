package grails_demo

import grails.converters.JSON
import idv.william.Enumeration
import idv.william.Utility
import grails.gorm.transactions.Transactional

final class ApiController {

    private def util = new Utility()

    def index() {}

    // MARK: - API
    /// 新增書籍
    /// => http://localhost:8080/api/appendBook?title=重新認識Vue.js：008天絕對看不完的Vue.js 3指南&releaseDate=2021-02-09
    /// => http://localhost:8080/api/appendBook?title=就算忙盲茫 我決定給自己一點時間&releaseDate=2021-03-02
    /// => http://localhost:8080/api/appendBook?title=天橋上的魔術師&releaseDate=2011-11-30
    def appendBook() {

        def title = util.queryString('title', this)
        def releaseDate = util.queryString('releaseDate', this)
        def json = this.appendBookResult(title, releaseDate)

        render(json)
    }

    /// 搜尋書籍 => http://localhost:8080/api/searchBook?id=3
    def searchBook() {

        def id = util.queryString('id', this) as Long
        def book = MyBook.findById(id)

        render(book.title)
    }

    /// 修改書籍 => http://localhost:8080/api/editBook?id=3&title=天橋上的魔術師ABC
    @Transactional
    def editBook() {

        def id = util.queryString('id', this) as Long
        def title = util.queryString('title', this) as String
        def myBook = MyBook.findById(id)

        myBook.title = title

        def result = myBook.save()                          // 將資料儲存到資料庫中
        def json = [result: result] as JSON                 // 將Map => JSON

        render(json)
    }

    /// 刪除書籍 => http://localhost:8080/api/deleteBook?id=3
    @Transactional
    def deleteBook() {

        def id = util.queryString('id', this) as Long
        def title = util.queryString('title', this) as String
        def myBook = MyBook.findById(id)

        myBook.delete()

        render("刪除完成")
    }

    // MARK: - Function
    /// 新增書籍
    private def appendBookResult(String title, String releaseDate) {

        if (title == null) {
            def json = [error: '沒打書名'] as JSON
            return json
        }

        if (releaseDate == null) {
            def json = [error: '沒打發行日期'] as JSON
            return json
        }

        def myBook = new MyBook()

        myBook.title = title
        myBook.releaseDate = util.stringToDate(releaseDate, Enumeration.DateFormat.Short)

        def result = myBook.save()                          // 將資料儲存到資料庫中
        def json = [result: result] as JSON                 // 將Map => JSON

        return json
    }
}