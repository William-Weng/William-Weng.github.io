package grails_demo

import grails.artefact.Controller

class FirstController {

    /// index()就是指grails-app/views/first/index.gsp => http://localhost:8080/first/index
    def index() {
        render('<h1>元宵節快樂</h1>')
    }
}