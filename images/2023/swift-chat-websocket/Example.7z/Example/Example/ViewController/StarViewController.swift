//
//  StarViewController.swift
//  Example
//
//  Created by iOS on 2023/4/25.
//

import UIKit
import WWPrint

// MARK: - 角色選擇頁
final class StarViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var starName: UIImageView!
    @IBOutlet var starSignList: [UIImageView]!
    
    private let segueId = "ChatViewControllerSegue"
    private var selectedStarSign: Constant.StarSign?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initSetting()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let viewController = segue.destination as? ChatViewController else { return }
        viewController.starSign = selectedStarSign
    }
}

// MARK: - @objc
extension StarViewController {
    
    /// 選擇星座
    /// - Parameter tap: UITapGestureRecognizer
    @objc func starSignTapAction(_ tap: UITapGestureRecognizer) {
        
        guard let imageView = tap.view as? UIImageView else { return }
        
        starName.image = imageView.image
        selectedStarSign = Constant.StarSign(rawValue: imageView.tag)
        titleLabel.text = selectedStarSign?.name()
    }
    
    /// 前往下一頁
    /// - Parameter tap: UITapGestureRecognizer
    @objc func starNameTapAction(_ tap: UITapGestureRecognizer) {
        guard selectedStarSign != nil else { return }
        performSegue(withIdentifier: segueId, sender: self)
    }
}

// MARK: - 小工具
extension StarViewController {
    
    /// 初始化設定
    func initSetting() {
        starNameSetting()
        starSignListSetting()
    }
    
    /// 星座點擊功能設定
    func starSignListSetting() {
        
        var index = 0
        
        starSignList.forEach { starSign in
            
            let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(starSignTapAction(_:)))
            
            starSign.isUserInteractionEnabled = true
            starSign.addGestureRecognizer(tapGestureRecognizer)
            starSign.tag = index
            
            index += 1
        }
    }
    
    /// 被選擇的星座點擊功能設定
    func starNameSetting() {
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(starNameTapAction(_:)))
        
        starName.isUserInteractionEnabled = true
        starName.addGestureRecognizer(tapGestureRecognizer)
    }
}
