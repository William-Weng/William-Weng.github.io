//
//  ViewController.swift
//  Example
//
//  Created by William.Weng on 2022/12/15.
//  ~/Library/Caches/org.swift.swiftpm/
//  file:///Users/william/Desktop/WWCropViewController
// [【12星座英文】到底怎麼講？教你用英文跟大家都聊得來！-巨匠美語](https://www.soeasyedu.com.tw/blog/online-learning/2018/03/twelve-constellations)

import UIKit
import WWPrint
import PhotosUI

// MARK: - 對話功能頁
final class ChatViewController: UIViewController {
    
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var myTextField: UITextField!
    @IBOutlet weak var starImageView: UIImageView!
    @IBOutlet weak var connentView: UIView!
    @IBOutlet weak var keyboardConstraintHeight: NSLayoutConstraint!
    
    static var chatMessageList: [Constant.ChatMessage] = []
    
    var starSign: Constant.StarSign?
    
    private let ip = "192.168.1.110"
    private let port = "8899"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initSetting()
        keyboardNotification()
    }
    
    @objc func keyboardWillShow(_ notification: Notification) { keyboardNotification(notification) }
    @objc func dimissKeyboard() { view.endEditing(true) }
    
    @IBAction func connent(_ sender: UIBarButtonItem) {
                
        guard let id = starSign?.id() else { return }
        
        let socketUrl = "ws://\(ip):\(port)/echo/?id=\(id)"
        webSocketConnent(with: socketUrl)
    }
    
    @IBAction func sendMessage(_ sender: UIButton) {
        sendWebSocketString(myTextField.text)
    }
    
    @IBAction func sendImage(_ sender: UIButton) {
        
        let picker = PHPickerViewController._photoLibrary(delegate: self)
        present(picker, animated: true)
    }
    
    deinit {
        WWWebSocket.shared.cancel()
        wwPrint("deinit => \(self)")
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension ChatViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Self.chatMessageList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = chatCellMaker(tableView, cellForRowAt: indexPath) else { fatalError() }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        dimissKeyboard()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                
        guard let chatMessage = Self.chatMessageList[safe: indexPath.row] else { return UITableView.automaticDimension }
        
        switch chatMessage.type {
        case .text: return UITableView.automaticDimension
        case .image: return view.frame.width * 0.5
        case .video: return view.frame.width * 0.5
        }
    }
}

// MARK: - UITextFieldDelegate
extension ChatViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

// MARK: - PHPickerViewControllerDelegate
extension ChatViewController: PHPickerViewControllerDelegate {
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        
        picker.dismiss(animated: true)
        
        guard let itemProvider = results.map(\.itemProvider).first else { return }
        
        itemProvider._data(forType: UIImage.self) { result in
            switch result {
            case .failure(let error): wwPrint(error)
            case .success(let image): self.sendWebSocketImage(image)
            }
        }
    }
}

// MARK: - 小工具
private extension ChatViewController {
    
    /// 初始化設定
    func initSetting() {
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(Self.dimissKeyboard))
        
        myTableView.delegate = self
        myTableView.dataSource = self
        myTextField.delegate = self
        myTableView.addGestureRecognizer(tapGesture)
        
        title = starSign?.name()
        starImageView.image = starSign?.image()
        keyboardConstraintHeight.constant = 0
    }
    
    /// 鍵盤顯示 / 隱藏通知設定
    func keyboardNotification() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    /// WebSocket連線 (自動重新連線) => ws:// + wss://
    /// - Parameters:
    ///   - url: String
    ///   - isAutoConnent: isAutoConnent
    func webSocketConnent(with url: String, isAutoConnent: Bool = true) {
        
        WWWebSocket.shared.cancel()
        
        WWWebSocket.shared.connent(with: url) { [weak self] `protocol` in
            self?.connentView.backgroundColor = .systemBlue
        } didCloseWithCode: { [weak self] closeCode, data in
            self?.connentView.backgroundColor = .lightGray
        } receiveResult: { [weak self] result in
            switch result {
            case .failure(let error):
                if (isAutoConnent) { self?.webSocketConnent(with: url, isAutoConnent: isAutoConnent) }
                self?.connentView.backgroundColor = .lightGray
                wwPrint(error)
            case .success(let message):
                let isSuccess = self?.phaseMessage(message)
                wwPrint("isSuccess => \(isSuccess ?? false)")
            }
        }
    }
    
    /// 鍵盤事件通知處理
    /// - Parameter notification: Notification
    func keyboardNotification(_ notification: Notification) {
        
        guard let info = UIDevice._keyboardInfomation(notification: notification),
              let curveType = UIView.AnimationCurve(rawValue: Int(info.curve))
        else {
            return
        }
        
        keyboardConstraintHeight.constant = view.frame.height - info.frame.origin.y
        
        let animator = UIViewPropertyAnimator(duration: info.duration, curve: curveType) { [weak self] in
            guard let this = self else { return }
            this.view.layoutIfNeeded()
        }
        
        animator.startAnimation()
    }
    
    /// Cell的長相設定 (名字是自己的 => MasterTableViewCell / 名字是其它人的 => SlaveTableViewCell)
    /// - Parameters:
    ///   - tableView: UITableView
    ///   - indexPath: IndexPath
    /// - Returns: UITableViewCell?
    func chatCellMaker(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell? {
        
        let message = ChatViewController.chatMessageList[indexPath.row]
        let name = starSign?.name()
        
        if (message.name != name) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SlaveTableViewCell") as? SlaveTableViewCell
            cell?.config(with: indexPath)
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MasterTableViewCell") as? MasterTableViewCell
        cell?.config(with: indexPath)
        return cell
    }
    
    /// 傳送文字訊息
    /// - Parameter message: String?
    func sendWebSocketString(_ message: String?) {
        
        guard let message = message,
              let starSign = starSign,
              !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        else {
            return
        }
        
        let chatMessage = """
        {"tag":\(starSign.rawValue),"name":"\(starSign.name())","text":"\(message)","type":\(Constant.MessageType.text.rawValue)}
        """
        
        WWWebSocket.shared.sendMessage(.string(chatMessage)) { error in
            if let error = error { wwPrint(error) }
        }
    }
    
    /// 傳送圖片訊息 (Base64String)
    /// - Parameter image: UIImage?
    func sendWebSocketImage(_ image: UIImage?) {
        
        guard let image = image,
              let data = image.pngData(),
              let starSign = starSign
        else {
            return
        }
        
        let chatMessage = """
        {"tag":\(starSign.rawValue),"name":"\(starSign.name())","text":"\(data._base64String())","type":\(Constant.MessageType.image.rawValue)}
        """
        
        if let data = chatMessage._data() {
            WWWebSocket.shared.sendMessage(.data(data)) { error in
                if let error = error { wwPrint(error) }
            }
        }
    }
    
    /// 解析WebSocket傳來的Message
    /// - Parameter message: URLSessionWebSocketTask.Message
    /// - Returns: Bool
    func phaseMessage(_ message: URLSessionWebSocketTask.Message) -> Bool {
        
        let jsonObject: Any?
        
        switch message {
        case .string(let string): jsonObject = string._jsonObject()
        case .data(let data): jsonObject = data._jsonObject()
        @unknown default: jsonObject = nil
        }
        
        guard let jsonObject = jsonObject,
              let dictionary = jsonObject as? [String: Any],
              let rawValue = dictionary["type"] as? Int,
              let type = Constant.MessageType(rawValue: rawValue)
        else {
            return false
        }
        
        let chatMessage = Constant.ChatMessage(tag: dictionary["tag"] as? Int, name: dictionary["name"] as? String, text: dictionary["text"] as? String, type: type)
        Self.chatMessageList.append(chatMessage)
        
        let indexPath = IndexPath(row: Self.chatMessageList.count - 1, section: 0)
        myTableView.insertRows(at: [indexPath], with: .none)
        myTableView.selectRow(at: indexPath, animated: true, scrollPosition: .bottom)
        myTextField.text = ""
        
        return true
    }
}
