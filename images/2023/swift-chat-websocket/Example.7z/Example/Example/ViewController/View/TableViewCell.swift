//
//  TableViewCell.swift
//  Example
//
//  Created by William.Weng on 2023/4/24.
//

import UIKit

// MARK: - 自己的對話框
final class MasterTableViewCell: UITableViewCell {
    
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var chatImageView: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var messageLabelLeading: NSLayoutConstraint!

    /// 設定Cell長相
    /// - Parameter indexPath: IndexPath
    func config(with indexPath: IndexPath) {
        
        let message = ChatViewController.chatMessageList[indexPath.row]
                
        nameLabel.text = message.name
        iconImageView.image = Constant.StarSign(rawValue: message.tag ?? 0)?.image()
        chatMessageSetting(message)
    }
    
    func chatMessageSetting(_ message: Constant.ChatMessage) {
        
        switch message.type {
        case .text:
            
            messageLabel.text = message.text
            messageLabelLeading.constant = 16
            chatImageView.contentMode = .scaleToFill
            chatImageView.image = UIImage(named: "ChatRight")
            
        case .image:
            
            guard let base64String = message.text,
                  let imageData = Data(base64Encoded: base64String)
            else {
                return
            }
            
            messageLabel.text = nil
            messageLabelLeading.constant = 192
            chatImageView.contentMode = .scaleAspectFit
            chatImageView.image = UIImage(data: imageData)
            
        case .video:
            break
        }
    }
}

// MARK: - 別人的對話框
final class SlaveTableViewCell: UITableViewCell {
    
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var chatImageView: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var messageLabelTrailing: NSLayoutConstraint!
    
    /// 設定Cell長相
    /// - Parameter indexPath: IndexPath
    func config(with indexPath: IndexPath) {
        
        let message = ChatViewController.chatMessageList[indexPath.row]
        
        nameLabel.text = message.name
        iconImageView.image = Constant.StarSign(rawValue: message.tag ?? 0)?.image()
        chatMessageSetting(message)
    }
    
    func chatMessageSetting(_ message: Constant.ChatMessage) {
        
        switch message.type {
        case .text:
            
            messageLabel.text = message.text
            messageLabelTrailing.constant = 16
            chatImageView.contentMode = .scaleToFill
            chatImageView.image = UIImage(named: "ChatLeft")
            
        case .image:
            
            guard let base64String = message.text,
                  let imageData = Data(base64Encoded: base64String)
            else {
                return
            }
            
            messageLabel.text = nil
            messageLabelTrailing.constant = 192
            chatImageView.contentMode = .scaleAspectFit
            chatImageView.image = UIImage(data: imageData)
            
        case .video:
            break
        }
    }
}
