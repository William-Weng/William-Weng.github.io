//
//  Extension.swift
//  Example
//
//  Created by William.Weng on 2022/12/15.
//

import UIKit
import PhotosUI

// MARK: - Collection (override class function)
extension Collection {

    /// [為Array加上安全取值特性 => nil](https://stackoverflow.com/questions/25329186/safe-bounds-checked-array-lookup-in-swift-through-optional-bindings)
    subscript(safe index: Index) -> Element? { return indices.contains(index) ? self[index] : nil }
}

// MARK: - String
extension String {
    
    /// String => Data
    /// - Parameters:
    ///   - encoding: 字元編碼
    ///   - isLossyConversion: 失真轉換
    /// - Returns: Data?
    func _data(using encoding: String.Encoding = .utf8, isLossyConversion: Bool = false) -> Data? {
        let data = self.data(using: encoding, allowLossyConversion: isLossyConversion)
        return data
    }
    
    /// JSON String => JSON Object
    /// - Parameters:
    ///   - encoding: 字元編碼
    ///   - options: JSON序列化讀取方式
    /// - Returns: Any?
    func _jsonObject(encoding: String.Encoding = .utf8, options: JSONSerialization.ReadingOptions = .allowFragments) -> Any? {
        
        guard let data = self._data(using: encoding),
              let jsonObject = try? JSONSerialization.jsonObject(with: data, options: options)
        else {
            return nil
        }
        
        return jsonObject
    }
}

// MARK: - Data
extension Data {
    
    /// Data => JSON
    /// - 7b2268747470223a2022626f6479227d => {"http": "body"}
    /// - Returns: Any?
    func _jsonObject(options: JSONSerialization.ReadingOptions = .allowFragments) -> Any? {
        let json = try? JSONSerialization.jsonObject(with: self, options: options)
        return json
    }
    
    /// [Data => Base64文字](https://zh.wikipedia.org/zh-tw/Base64)
    /// - Parameter options: Base64EncodingOptions
    /// - Returns: Base64EncodingOptions
    func _base64String(options: Base64EncodingOptions = []) -> String {
        return self.base64EncodedString(options: options)
    }
}

// MARK: - UIDevice
extension UIDevice {
    
    /// 取得鍵盤相關資訊
    /// - UIResponder.keyboardDidShowNotification / UIResponder.keyboardDidHideNotification
    /// - Parameter notification: 鍵盤的notification
    /// - Returns: Constant.KeyboardInfomation?
    static func _keyboardInfomation(notification: Notification) -> Constant.KeyboardInfomation? {
        
        guard let userInfo = notification.userInfo,
              let duration = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double,
              let curve = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as? UInt,
              let frame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect
        else {
            return nil
        }
        
        return (duration: duration, curve: curve, frame: frame)
    }
}

// MARK: - UINavigationBarAppearance (class function)
extension UINavigationBarAppearance {
    
    /// 設定背景色透明 - UINavigationBar.appearance()._transparent()
    /// - Returns: UINavigationBarAppearance
    func _transparent() -> Self { configureWithTransparentBackground(); return self }
}

// MARK: - UINavigationBar (class function)
extension UINavigationBar {
    
    /// [透明背景 (透明底線) => application(_:didFinishLaunchingWithOptions:)](https://sarunw.com/posts/uinavigationbar-changes-in-ios13/)
    func _transparent() {
        self.standardAppearance = UINavigationBarAppearance()._transparent()
    }
}

// MARK: - PHPickerViewController (static function)
extension PHPickerViewController {
    
    /// [產生多選的PickerViewController](https://medium.com/彼得潘的-swift-ios-app-開發教室/phpickerviewcontroller-總是糾結在單選與多選的你-像極了愛情-5005e321f55a)
    /// - Parameters:
    ///   - delegate: PHPickerViewControllerDelegate?
    ///   - filter: PHPickerFilter
    ///   - selectionLimit: 最多選幾張？
    /// - Returns: PHPickerViewController
    static func _build(delegate: PHPickerViewControllerDelegate? = nil, filter: PHPickerFilter? = .images, selectionLimit: Int = 1) -> PHPickerViewController {
        
        let configuration = PHPickerConfiguration._build(filter: filter, selectionLimit: selectionLimit)
        let picker = PHPickerViewController(configuration: configuration)
        
        picker.delegate = delegate
        
        return picker
    }
    
    /// [產生圖片選取框](https://medium.com/彼得潘的-swift-ios-app-開發教室/phpickerviewcontroller-總是糾結在單選與多選的你-像極了愛情-5005e321f55a)
    /// - Parameters:
    ///   - delegate: PHPickerViewControllerDelegate?
    ///   - selectionLimit: 最多選幾張？
    /// - Returns: PHPickerViewController
    static func _photoLibrary(delegate: PHPickerViewControllerDelegate? = nil, selectionLimit: Int = 1) -> PHPickerViewController {
        return Self._build(delegate: delegate, filter: .images, selectionLimit: selectionLimit)
    }
}

// MARK: - PHPickerConfiguration (static function)
extension PHPickerConfiguration {
    
    /// 多選的PickerViewController設定檔
    /// - Parameters:
    ///   - filter: PHPickerFilter
    ///   - selectionLimit: 最多選幾張？
    /// - Returns: PHPickerConfiguration
    static func _build(filter: PHPickerFilter? = .images, selectionLimit: Int = 1) -> PHPickerConfiguration {
        
        var configuration = PHPickerConfiguration()
        configuration.filter = filter
        configuration.selectionLimit = selectionLimit
        
        return configuration
    }
}

// MARK: - NSItemProvider (class function)
extension NSItemProvider {
    
    /// [取得PHPickerViewController所選的內容 => 圖片 / 影片](https://medium.com/彼得潘的-swift-ios-app-開發問題解答集/ios-14-提供多選照片功能的-phpickerviewcontroller-d9733d203222)
    /// - Parameters:
    ///   - type: T.Type
    ///   - result: Result<T, Error>
    func _data<T: NSItemProviderReading>(forType type: T.Type = UIImage.self, result: @escaping (Result<T, Error>) -> Void) {
        
        guard self.canLoadObject(ofClass: type) else { result(.failure(Constant.MyError.isEmpty)); return }
        
        self.loadObject(ofClass: type) { reading, error in
            
            if let error = error { result(.failure(error)); return }
            
            guard let reading = reading,
                  let data = reading as? T
            else {
                result(.failure(Constant.MyError.isEmpty)); return
            }
            
            result(.success(data))
        }
    }
}
