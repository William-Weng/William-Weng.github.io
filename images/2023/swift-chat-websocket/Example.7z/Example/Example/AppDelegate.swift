//
//  AppDelegate.swift
//  Example
//
//  Created by William.Weng on 2022/12/15.
//

import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        UINavigationBar.appearance()._transparent()
        return true
    }
}

