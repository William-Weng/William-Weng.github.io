package utility

import (
	"fmt"
	"runtime"
	"time"
)

// [印出結果](https://dotblogs.com.tw/DizzyDizzy/2019/11/29/ColorfulCLI) => log.SetFlags(log.LstdFlags | log.Lshortfile)
func Println(value ...any) {

	now := time.Now()
	pc, filename, line, _ := runtime.Caller(1)
	functionName := runtime.FuncForPC(pc).Name()

	content := fmt.Sprintf("\033[37;103m[LOG] %v\033[0m", now)
	fmt.Println(content)

	content = fmt.Sprintf("\033[37;103m%s: %v => %v\033[0m", filename, line, functionName)
	fmt.Println(content)
	fmt.Println(value...)
}
