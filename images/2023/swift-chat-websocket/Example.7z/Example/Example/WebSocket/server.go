package main

import (
	"fmt"
	"log"
	"net/http"
	"william/utility"

	"github.com/gorilla/websocket"
)

type Client struct {
	conn *websocket.Conn
	name string
}

const (
	port     = "8899"
	path     = "/echo/"
	queryKey = "id"
)

var clientName string = ""
var clients = make(map[**websocket.Conn]Client)

func main() {
	webSocketSetting()
}

// WebSocket功能設定
func webSocketSetting() {

	upgrader := webSocketUpgraderMaker(true)

	http.HandleFunc(path, func(writer http.ResponseWriter, request *http.Request) {

		connect, error := upgrader.Upgrade(writer, request, nil)
		clientName = request.URL.Query()["id"][0]

		if len(clientName) == 0 {
			utility.Println("id => null")
			return
		}

		if error != nil {
			utility.Println("connect => ", error)
			return
		}

		defer func() {

			message := fmt.Sprintf("%p is disconnect !!!.", &connect)

			utility.Println(message)
			connect.Close()
			delete(clients, &connect)
			utility.Println(clients)
		}()

		client := Client{
			conn: connect,
			name: clientName,
		}

		clients[&connect] = client
		utility.Println(&connect)

		for {
			messageType, message, error := connect.ReadMessage()

			if error != nil {
				utility.Println("read:", error)
				break
			}

			broadcastMessage(messageType, string(message))
		}
	})

	url := fmt.Sprintf(":%s", port)
	serverStart := fmt.Sprintf("server start at :%s", port)

	utility.Println(serverStart)
	log.Fatal(http.ListenAndServe(url, nil))
}

// 產生WebSocketUpgrader元件
func webSocketUpgraderMaker(notCheckCORS bool) *websocket.Upgrader {

	upgrader := &websocket.Upgrader{
		CheckOrigin: func(request *http.Request) bool { return notCheckCORS },
	}

	return upgrader
}

// 廣播訊息
func broadcastMessage(messageType int, message string) {

	utility.Println(message)

	for _, client := range clients {

		error := client.conn.WriteMessage(messageType, []byte(message))

		if error != nil {
			utility.Println("Write Error => ", error)
			break
		}
	}
}
