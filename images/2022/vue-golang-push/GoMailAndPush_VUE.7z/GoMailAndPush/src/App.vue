<template>
  <div class="app">

    <el-header>GoGo垃圾信</el-header>

    <!-- 資料 -->
    <el-table :data="users">
      <el-table-column prop="name" :label="userLabel.name" width="100"/>
      <el-table-column prop="mail" :label="userLabel.mail" width="256"/>
      <el-table-column prop="system" :label="userLabel.system" width="100"/>
      <el-table-column prop="token" :label="userLabel.token"/>
      <el-table-column fixed="right" :label="userLabel.operations" width="200">
        <template #default="scope">
          <el-button color="#626aef" round @click="handleVisibleDialog(scope.row, true, 'eMail')">垃圾信</el-button>
          <el-button color="#F1F30A" round @click="handleVisibleDialog(scope.row, true, 'Push')">垃圾推播</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 編譯框 -->
    <el-dialog v-model="isVisibleDialog" :title="userLabel.dialogTitle" background="red">
      <el-form-item :label="userLabel.title" label-width="320"><el-input v-model="temp.title" autocomplete="off" /></el-form-item>  
      <el-form-item :label="userLabel.message" label-width="320"><el-input v-model="temp.message" autocomplete="off" /></el-form-item>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleVisibleDialog(null, false, '')">Cancel</el-button>
          <el-button type="primary" @click="handleSendMessage(username)">Confirm</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import axios from 'axios'
import User from "./models/User";
import SendTypeEnum from "./models/SendTypeEnum";

export default defineComponent({
  name: 'App',
  components: {
  },
  setup() {

    const Constant = {

      UserLabel: ref({
        name: "姓名",
        mail: "電子信箱",
        system: "系統",
        token: "推播",
        operations: "功能",
        title: "標題",
        message: "內容",
        dialogTitle: "發送垃圾信"
      }),

      GolangAPI: {
        userList: "http://localhost:12345/user",
        sendMessage: "http://localhost:12345/mail",
        pushNotification: "http://localhost:12345/push"
      }
    }

    const API = {

      /// 取得使用者List
      userList: async (url: string) => {
        
        const response = await axios.get(url)
        const { result, _ } = response.data
        const users = result as any[]

        return users
      },

      /// 發發垃圾信
      sendMail: async (name: string) => {

        const url = `${Constant.GolangAPI.sendMessage}/${name}`
        const response = await axios.post(url, {
          "title": tempFormInformation.value.title, 
          "message": tempFormInformation.value.message
        })

        const { result, _ } = response.data
        return result
      },

      /// 發發垃圾推播
      pushNotification: async (name: string) => {

        const url = `${Constant.GolangAPI.pushNotification}/${name}`
        const response = await axios.post(url, {
          "title": tempFormInformation.value.title, 
          "message": tempFormInformation.value.message
        })

        const { result, _ } = response.data
        return result
      },
    }

    let users = ref<User[]>([])
    let username = ref("")
    let isVisibleDialog = ref(false)
    let sendType = ref<SendTypeEnum>("eMail")
    let tempFormInformation = ref({ title: "", message: "" })

    /// 取得User列表
    API.userList(Constant.GolangAPI.userList).then((_users) => {
        _users.forEach((user: any) => {
          const _user = { name: user.name, mail: user.mail, system: user.system, token: user.token }
          users.value.push(_user)
        })
    })

    /// Dialog開關
    const handleVisibleDialog = (user: User, isVisible: boolean, type: SendTypeEnum) => {

      isVisibleDialog.value = isVisible
      sendType.value = type
      username.value = user.name

      switch (type) {
        case "eMail": Constant.UserLabel.value.dialogTitle = `${'\uD83D\uDC36'} 發送垃圾信`; break
        case "Push": Constant.UserLabel.value.dialogTitle = `${'\u200D\u2764\uFE0F\u200D'} 發送垃圾推播`; break
        default: break
      }

      tempFormInformation.value = { title: "", message: "" }
    }

    /// 發送垃圾信 / 發送垃圾推播
    const handleSendMessage = (name: string) => {
      
      switch (sendType.value) {
        case "eMail": API.sendMail(name); break
        case "Push": API.pushNotification(name); break
        default: break
      }

      isVisibleDialog.value = false
      tempFormInformation.value = { title: "", message: "" }
    }

    return { users, username, userLabel: Constant.UserLabel, handleVisibleDialog, handleSendMessage, temp: tempFormInformation, isVisibleDialog }
  }
});
</script>

<style>
#app {
  text-align: center;
  color: #c3114c;
  margin-top: 60px;
}
</style>
