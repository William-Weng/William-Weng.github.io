type SendTypeEnum = 'eMail' | 'Push' | 'SMS'

export default SendTypeEnum