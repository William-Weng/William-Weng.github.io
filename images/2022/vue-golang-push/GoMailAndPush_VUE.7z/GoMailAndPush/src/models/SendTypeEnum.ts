type SendTypeEnum = 'eMail' | 'Push'

export default SendTypeEnum