interface User {
    name: string,
    mail: string,
    system: number,
    token: string,
}

export default User