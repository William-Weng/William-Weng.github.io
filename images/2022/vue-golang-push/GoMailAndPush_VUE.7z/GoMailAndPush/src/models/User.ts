interface User {
    name: string,
    mail: string,
    phone: string,
    system: string,
    token: string,
}

export default User