//
//  ViewController.swift
//  GoMailAndPush
//
//  Created by iOS on 2022/4/26.
//

import UIKit
import WWPrint
import WWNetworking
import WWHUD

final class ViewController: UIViewController {
            
    private let ApiUrl = "http://192.168.1.102:12345"
    
    override func viewDidLoad() { super.viewDidLoad() }

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var eMailTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        self.view.endEditing(true)
    }
    
    /// 使用者註冊
    @IBAction func registerUser(_ sender: UIBarButtonItem) {
        self.view.endEditing(true)
        self.register()
    }
    
    /// 使用者更新deviceToken
    @IBAction func upddateDeviceToken(_ sender: UIBarButtonItem) {
        
        guard let deviceToken = self.deviceToken() else { return }
        
        self.view.endEditing(true)
        self.update(deviceToken: deviceToken)
    }
}

// MARK: - 小工具
private extension ViewController {
    
    /// 取得推播的deviceToken
    func deviceToken() -> String? {
        
        guard let appDelegate = (UIApplication.shared.delegate) as? AppDelegate,
              let deviceToken = appDelegate.deviceToken
        else {
            return nil
        }

        return deviceToken
    }
    
    /// 使用者註冊
    func register() {
        
        let urlString = "\(ApiUrl)/user"
        
        let json: [String: Any?] = [
            "system": 0,
            "name": usernameTextField.text,
            "mail": eMailTextField.text,
            "phone": phoneTextField.text
        ]
        
        WWNetworking.shared.request(with: .POST, urlString: urlString, contentType: .json, paramaters: [:], headers: nil, httpBody: json._jsonSerialization()) { result in
            self.responseAction(result: result)
        }
    }
    
    /// 更新使用者deviceToken
    func update(deviceToken: String) {
        
        let urlString = "\(ApiUrl)/user/\(usernameTextField.text ?? "")"
        
        let json: [String: Any?] = [
            "system": 0,
            "token": deviceToken
        ]
        
        WWNetworking.shared.request(with: .PATCH, urlString: urlString, contentType: .json, paramaters: nil, headers: nil, httpBody: json._jsonSerialization()) { result in
            self.responseAction(result: result)
        }
    }
    
    /// 顯示提示的HUD
    func flashHud(isSuccess: Bool) {
        
        var effect = WWHUD.AnimationEffect.shake(image: #imageLiteral(resourceName: "success"), angle: 10.0, duration: 0.25)
        var backgroundColor = UIColor.yellow.withAlphaComponent(0.3)
        
        defer {
            DispatchQueue.main.async {
                WWHUD.shared.flash(effect: effect, height: 250, backgroundColor: backgroundColor, animation: 0.5, options: .curveEaseIn, completion: nil)
            }
        }
        
        if (!isSuccess) {
            effect = .shake(image: #imageLiteral(resourceName: "fail"), angle: 10.0, duration: 0.25)
            backgroundColor = UIColor.gray.withAlphaComponent(0.3)
        }
    }
    
    /// 取得Response的處理
    func responseAction(result: Result<WWNetworking.ResponseInformation, Error>) {
        
        var isSuccess = false
        
        defer { self.flashHud(isSuccess: isSuccess) }
        
        switch result {
        case .failure(let error): wwPrint(error)
        case .success(let info):
            
            guard let json = info.data?._jsonObject(),
                  let dictionary = json as? [String: Any],
                  let result = dictionary["result"] as? [String: Any],
                  let _isSuccess = result["isSuccess"] as? Bool
            else {
                return
            }
            
            isSuccess = _isSuccess
        }
    }
}
