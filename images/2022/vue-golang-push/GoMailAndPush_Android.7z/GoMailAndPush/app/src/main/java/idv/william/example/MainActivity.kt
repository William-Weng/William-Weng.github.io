package idv.william.example

// [碼農日常-『Android studio』Toolbar之基本用法 @ 碼農日常大小事 :: 痞客邦 ::](https://thumbb13555.pixnet.net/blog/post/326451188-toolbar)
// [Day 17 - 建立選單(Menu) - iT 邦幫忙::一起幫忙解決難題，拯救 IT 人的一天](https://ithelp.ithome.com.tw/articles/10188217)
// [【APP/Android】如何自己設計 Toolbar (Action Bar) - SpicyBoyd 部落格](https://spicyboyd.blogspot.com/2018/04/app-toolbar-actionbar.html)
// [Android OkHttp 教學 (Kotlin 篇)](https://tw-hkt.blogspot.com/2020/07/android-okhttp-kotlin.html)
// [碼農日常-『Android studio』FCM雲端推播與通知系統(上)-建立第一個基本推播通知APP @ 碼農日常大小事 :: 痞客邦 ::](https://thumbb13555.pixnet.net/blog/post/333378541-notification)

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException


class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var usernameEditText: EditText
    private lateinit var eMailEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var token: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initSetting()

        FirebaseMessaging.getInstance().subscribeToTopic("news")
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) return@OnCompleteListener
            token = task.result
        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            R.id.action_item_register -> { registerUser(); true }
            R.id.action_item_setting ->{ settingUser(); true }
            else -> { super.onOptionsItemSelected(item) }
        }
    }

    // 初始化設定
    private fun initSetting() {

        toolbar = this.findViewById(R.id.toolbar)
        toolbar.title = "GoGo垃圾信"

        usernameEditText = this.findViewById(R.id.username)
        eMailEditText = this.findViewById(R.id.eMail)
        phoneEditText = this.findViewById(R.id.phone)

        setSupportActionBar(toolbar)
    }

    // 顯示提示Toast
    private fun showToast(text: String) {
        Log.d("[TOAST]", text)
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    // 產生Request (POST)
    private fun requestPostMaker(urlString: String, json: String): Request {
        val body = json.toRequestBody()
        this.showToast(urlString)
        return Request.Builder().url(urlString).post(body).build()
    }

    // 產生Request (PATCH)
    private fun requestPatchMaker(urlString: String, json: String): Request {
        val body = json.toRequestBody()
        return Request.Builder().url(urlString).patch(body).build()
    }

    // 註冊User
    private fun registerUser() {

        val map = mapOf(
            "system" to 1,
            "name" to usernameEditText.text.toString(),
            "mail" to eMailEditText.text.toString(),
            "phone" to phoneEditText.text.toString()
        )

        val urlString = "http://192.168.1.103:12345/user/"
        val json = JSONObject(map).toString()
        val request = this.requestPostMaker(urlString = urlString, json = json)

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) { runOnUiThread { showToast(text = error.toString()) } }
            override fun onResponse(call: Call, response: Response) { runOnUiThread { showToast(text = "成功") } }
        })
    }

    // 更新Token
    private fun settingUser() {

        val map = mapOf(
            "system" to 1,
            "token" to token,
        )

        val urlString = "http://192.168.1.103:12345/user/" + usernameEditText.text.toString()
        val json = JSONObject(map).toString()
        val request = this.requestPatchMaker(urlString = urlString, json = json)

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) { runOnUiThread { showToast(text = error.toString()) } }
            override fun onResponse(call: Call, response: Response) { runOnUiThread { showToast(text = "成功") } }
        })
    }
}