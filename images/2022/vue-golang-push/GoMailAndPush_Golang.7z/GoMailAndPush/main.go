package main

import (
	"net/http"

	"william/model"
	"william/utility"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

const DatabasePath string = "./file/push.sqlite3"

var User model.User

// [程式一開始要初始化的東西](https://blog.csdn.net/wide288/article/details/92808990)
func init() {
}

func main() {

	database, error := utility.Sqlite3.CreateDatabase(DatabasePath)

	if error != nil {
		utility.Println(error)
	}

	error = database.AutoMigrate(&model.User{})
	if error != nil {
		utility.Println(error)
	}

	routerSetting(database)
}

// [初始化Router相關設定](https://blog.csdn.net/fbbqt/article/details/114386445)
func routerSetting(database *gorm.DB) {

	corsConfig := cors.DefaultConfig() // 防止CORS的設定
	corsConfig.AllowAllOrigins = true  // 防止CORS的設定

	router := gin.Default()
	router.MaxMultipartMemory = 8 << 20

	router.Use(cors.New(corsConfig))
	registerWebAPI(router, database)
	router.Run(":12345")
}

// 註冊API
func registerWebAPI(router *gin.Engine, database *gorm.DB) {
	selectUser(router, database)
	selectAllUser(router, database)
	insertUser(router, database)
	updateUser(router, database)
	mailUser(router, database)
	pushNotificationUser(router, database)
}

// MARK: - WebAPI
// <GET>搜尋單一使用者 => http://localhost:12345/user/william
func selectUser(router *gin.Engine, database *gorm.DB) {

	router.GET("/user/:name", func(context *gin.Context) {

		name := context.Param("name")
		user, error := User.Select(database, name)

		if user.ID != 0 {
			utility.ContextJSON(context, http.StatusOK, user, nil)
			return
		}

		utility.ContextJSON(context, http.StatusOK, nil, error)
	})
}

// <GET>搜尋使用者列表 => http://localhost:12345/user
func selectAllUser(router *gin.Engine, database *gorm.DB) {

	router.GET("/user", func(context *gin.Context) {

		users := User.SelectAll(database)

		utility.ContextJSON(context, http.StatusOK, users, nil)
	})
}

// <POST>新增單一使用者 => http://localhost:12345/user + {"system":0,"name":"William","mail":"linuxice0609@gmail.com","phone":"0912345678"}
func insertUser(router *gin.Engine, database *gorm.DB) {

	router.POST("/user", func(context *gin.Context) {

		dictionary := utility.RequestBodyToMap(context)
		result, error := User.Insert(database, dictionary)

		utility.ContextJSON(context, http.StatusOK, result, error)
	})
}

// <PATCH>更新單一使用者Token => http://localhost:12345/user/william + {"system":0,"token":"72b3ee73e5314cc4c1991dc9377f1f2c1c123dbc492f5c4197ab11f330b7568f"}
func updateUser(router *gin.Engine, database *gorm.DB) {

	router.PATCH("/user/:name", func(context *gin.Context) {

		name := context.Param("name")
		dictionary := utility.RequestBodyToMap(context)

		system := model.MobileSystem(dictionary["system"].(float64))
		token := dictionary["token"].(string)

		user, error := User.Select(database, name)

		if user.ID == 0 {
			utility.ContextJSON(context, http.StatusOK, nil, error)
			return
		}

		info := map[string]interface{}{
			"system": system,
			"token":  token,
		}

		result, error := user.Update(database, info)
		utility.ContextJSON(context, http.StatusOK, result, error)
	})
}

// <POST>給單一使用者發垃圾信 => http://localhost:12345/mail/william + {"title":"垃圾信", "message":"什麼事也沒有"}
func mailUser(router *gin.Engine, database *gorm.DB) {

	router.POST("/mail/:name", func(context *gin.Context) {

		name := context.Param("name")
		dictionary := utility.RequestBodyToMap(context)

		title := dictionary["title"].(string)
		message := dictionary["message"].(string)

		result, error := User.EMail(database, name, title, message)
		utility.ContextJSON(context, http.StatusOK, result, error)
	})
}

// <POST>給單一使用者發垃圾推播 => http://localhost:12345/push/william + {"title":"垃圾信", "message":"什麼事也沒有"}
func pushNotificationUser(router *gin.Engine, database *gorm.DB) {

	router.POST("/push/:name", func(context *gin.Context) {

		name := context.Param("name")
		dictionary := utility.RequestBodyToMap(context)

		result, error := User.PushNotification(database, name, dictionary)
		utility.ContextJSON(context, http.StatusOK, result, error)
	})
}
