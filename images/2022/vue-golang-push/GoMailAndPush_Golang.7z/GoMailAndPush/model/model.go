package model

import (
	"errors"
	"william/utility"

	"gorm.io/gorm"
)

type MobileSystem int8

type User struct {
	gorm.Model
	System MobileSystem `json:"system"`
	Name   string       `json:"name" sql:"CHARACTER SET utf8 COLLATE utf8_general_ci" gorm:"index:idx_name,unique"`
	Mail   string       `json:"mail" gorm:"unique"`
	Phone  string       `json:"phone" gorm:"unique"`
	Token  string       `json:"token"`
}

const (
	IOS     MobileSystem = 0
	Android MobileSystem = 1
)

var apnsInformation = utility.APNSInformation{
	AuthKeyP8: "./file/AuthKey.p8",
	KeyID:     "<KeyID>",
	TeamID:    "<TeamID>",
	Topic:     "idv.william.Example",
}

var fcmInformation = utility.FCMInformation{
	ApiKey: "<ApiKey>",
}

var gmailInformation = utility.GmailInformation{
	FromMail: "<eMail>",
	Password: "<Password>",
	Host:     "smtp.gmail.com",
	Port:     587,
	Title:    "",
	Message:  "",
}

var smsInformation = utility.SMSInformation{
	API:      "http://api.twsms.com/json/sms_send.php",
	Username: "<Username>",
	Password: "<Password>",
}

// MARK: - [User小工具](https://gorm.io/zh_CN/docs/query.html)
// 新增單一使用者 => ["name":"William","mail":"linuxice0609@gmail.com","phone":"0912345678"]
func (_user *User) Insert(database *gorm.DB, dictionary map[string]interface{}) (map[string]interface{}, error) {

	system := MobileSystem(dictionary["system"].(float64))
	name := dictionary["name"].(string)
	mail := dictionary["mail"].(string)
	phone := dictionary["phone"].(string)

	isSuccess := false
	error := database.Create(&User{System: system, Name: name, Mail: mail, Phone: phone}).Error

	if error == nil {
		isSuccess = true
	}

	result := map[string]interface{}{"isSuccess": isSuccess}
	return result, error
}

// 搜尋單一使用者 => name = william
func (_user *User) Select(database *gorm.DB, name string) (User, error) {

	var user User
	error := database.Take(&user, "name = ?", name).Error

	return user, error
}

// 搜尋使用者
func (_user *User) SelectAll(database *gorm.DB) []User {

	var users []User
	var _database = database

	_database.Find(&users)

	return users
}

// 更新單一使用者推播Token
func (_user *User) Update(database *gorm.DB, name string, info map[string]interface{}) (map[string]interface{}, error) {

	isSuccess := false
	user, error := _user.Select(database, name)
	result := map[string]interface{}{"isSuccess": isSuccess}

	if user.ID == 0 {
		return result, error
	}

	error = database.Model(&user).Updates(info).Error

	if error == nil {
		isSuccess = true
	}

	result = map[string]interface{}{"isSuccess": isSuccess}
	return result, error
}

// 給單一使用者發mail
func (_user *User) EMail(database *gorm.DB, name string, title string, message string) (map[string]interface{}, error) {

	user, error := _user.Select(database, name)

	if user.ID == 0 {
		result := map[string]interface{}{"isSuccess": false}
		return result, error
	}

	gmailInformation.Title = title
	gmailInformation.Message = message

	result, error := utility.GmailServer(gmailInformation, user.Mail)
	return result, error
}

// [給單一使用者發推播](https://blog.wu-boy.com/2017/03/error-handler-in-golang/)
func (_user *User) PushNotification(database *gorm.DB, name string, dictionary map[string]interface{}) (any, error) {

	user, error := _user.Select(database, name)
	title := dictionary["title"].(string)
	message := dictionary["message"].(string)

	if user.ID == 0 {
		return nil, error
	}

	if user.System == IOS {
		return utility.PushNotification(apnsInformation, user.Token, title, message)
	}

	if user.System == Android {
		return utility.FirebaseCloudMessaging(fcmInformation, user.Token, title, message)
	}

	return nil, errors.New("this system is not support")
}

// [給單一使用者發垃圾簡訊](https://ithelp.ithome.com.tw/articles/10159383)
func (_user *User) SMS(database *gorm.DB, name string, message string) (map[string]interface{}, error) {

	user, error := _user.Select(database, name)

	if user.ID == 0 {
		return nil, error
	}

	result, error := utility.SMS(smsInformation, user.Phone, message)
	return result, error
}
