package utility

import (
	"database/sql"

	"gorm.io/driver/mysql"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

type DatabaseType int8

// [MySQL連線的參數設定](https://gorm.io/zh_CN/docs/connecting_to_the_database.html)
type MySQLInformation struct {
	Username string
	Password string
	Host     string
	Port     int
	Database string
}

const (
	Sqlite3 DatabaseType = 0
	MySql   DatabaseType = 1
)

// [建立資料庫](https://cloud.tencent.com/developer/article/1830807)
func (dbType DatabaseType) CreateDatabase(path string) (*gorm.DB, error) {

	var database *gorm.DB
	var error error

	sqlLogger := logger.Default.LogMode(logger.Info)

	switch dbType {
	case Sqlite3:
		database, error = gorm.Open(sqlite.Open(path), &gorm.Config{Logger: sqlLogger})
	case MySql:
		databaseConnect, err := sql.Open("mysql", path)
		if err != nil {
			error = err
			break
		}
		database, error = gorm.Open(mysql.New(mysql.Config{Conn: databaseConnect}), &gorm.Config{Logger: sqlLogger})
	}

	return database, error
}
