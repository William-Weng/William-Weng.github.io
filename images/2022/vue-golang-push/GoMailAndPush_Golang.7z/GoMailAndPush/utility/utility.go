package utility

import (
	"crypto/ecdsa"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/smtp"
	"reflect"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/appleboy/go-fcm"
	"github.com/sideshow/apns2"
	"github.com/sideshow/apns2/token"
)

// [使用Gmail寄信的相關資訊](https://kb.synology.com/zh-tw/SRM/tutorial/How_to_use_Gmail_SMTP_server_to_send_emails_for_SRM)
type GmailInformation struct {
	FromMail string
	Password string
	Host     string
	Port     uint
	Title    string
	Message  string
}

// [APNS的.p8檔相關設定資訊](https://medium.com/彼得潘的-swift-ios-app-開發教室/推播-p8憑證匯出-d195dd6b801b)
type APNSInformation struct {
	AuthKeyP8 string
	KeyID     string
	TeamID    string
	Topic     string
}

// [FCM推播的相關設定資訊](https://firebase.google.com/)
type FCMInformation struct {
	ApiKey string
}

// [台灣簡訊的相關設定資訊](https://www.twsms.com/)
type SMSInformation struct {
	API      string
	Username string
	Password string
}

// [仿forEach()](https://openhome.cc/Gossip/Go/Closure.html) => forEach(numbers, func(element int, index int) { sum += element })
func ForEach[T any](elements []T, closure func(T, int)) {
	for index, element := range elements {
		closure(element, index)
	}
}

// [仿map()](https://medium.com/starbugs/why-go-need-generics-c8f1495ef00a) => title := Map(numbers, func(number int, index int) string { return strconv.Itoa(number * 2) })
func Map[T, U any](elements []T, closure func(T, int) U) []U {

	newElements := make([]U, len(elements))

	ForEach(elements, func(element T, index int) {
		newElements[index] = closure(element, index)
	})

	return newElements
}

// [印出結果](https://dotblogs.com.tw/DizzyDizzy/2019/11/29/ColorfulCLI)
func Println(value ...any) {

	_, filename, line, _ := runtime.Caller(1)

	title := fmt.Sprintf("\033[30;106m%v\033[0m", time.Now().Local())
	message := fmt.Sprintf("\033[30;102m[%s]\033[0m\033[30;103m%s:%d\033[0m %v", "DEBUG", filename, line, value)

	fmt.Println(title)
	fmt.Println(message)
}

// 文字 => 數字
func StringToInt(str string) (int, error) {
	return strconv.Atoi(str)
}

// 文字 => 大寫
func StringToUpper(str string) string {
	return strings.ToUpper(str)
}

// 讀取出類別
func TypeOf(object any) reflect.Type {
	return reflect.TypeOf(object)
}

// 將網路傳來的[]byte => map
func RawBodyToMap(rawJSON []byte) map[string]interface{} {

	dictionary := map[string]interface{}{}
	json.Unmarshal(rawJSON, &dictionary)

	return dictionary
}

// MAP (Dictionary) => JSONData
func MapToJSONData(dictionary map[string]interface{}) ([]byte, error) {
	return json.Marshal(dictionary)
}

// [使用Gmail寄信](https://support.google.com/mail/?p=InvalidSecondFactor)
func GmailServer(info GmailInformation, toMail string) (map[string]interface{}, error) {

	var isSuccess bool = false
	var error error = nil

	smtpServer := fmt.Sprintf("%s:%d", info.Host, info.Port)
	message := fmt.Sprintf("From: %s\nTo: %s\nSubject: %s\n\n %s", info.FromMail, toMail, info.Title, info.Message)
	authentication := smtp.PlainAuth("", info.FromMail, info.Password, info.Host)

	error = smtp.SendMail(smtpServer, authentication, info.FromMail, []string{toMail}, []byte(message))

	if error == nil {
		isSuccess = true
	}

	result := map[string]interface{}{"isSuccess": isSuccess}
	return result, error
}

// iOS推播功能
func PushNotification(info APNSInformation, deviceToken string, title string, message string) (*apns2.Response, error) {

	var authKey *ecdsa.PrivateKey = nil
	var response *apns2.Response = nil
	var error error = nil

	alert := map[string]interface{}{
		"title":    title,
		"subtitle": message,
	}

	jsonData, error := MapToJSONData(alert)
	if error != nil {
		return response, error
	}

	context := `{"aps":{"alert":` + string(jsonData) + `}}`
	payload := []byte(context)

	authKey, error = token.AuthKeyFromFile(info.AuthKeyP8)
	if error != nil {
		return response, error
	}

	notification := &apns2.Notification{}
	notification.Topic = info.Topic
	notification.DeviceToken = deviceToken
	notification.Payload = payload

	token := &token.Token{
		AuthKey: authKey,
		KeyID:   info.KeyID,
		TeamID:  info.TeamID,
	}

	client := apns2.NewTokenClient(token).Development()
	response, error = client.Push(notification)

	if error != nil {
		return response, error
	}

	return response, error
}

// Android推播功能
func FirebaseCloudMessaging(info FCMInformation, deviceToken string, title string, body string) (*fcm.Response, error) {

	apiKey := info.ApiKey

	message := &fcm.Message{
		To: deviceToken,
		Data: map[string]interface{}{
			"foo": "bar",
		},
		Notification: &fcm.Notification{
			Title: title,
			Body:  body,
		},
	}

	client, error := fcm.NewClient(apiKey)

	if error != nil {
		return nil, error
	}

	return client.Send(message)
}

// 發送SMS簡訊
func SMS(info SMSInformation, mobile string, message string) (map[string]interface{}, error) {

	result := map[string]interface{}{}
	apiUrl := fmt.Sprintf("%s?username=%s&password=%s&mobile=%s&message=%s", info.API, info.Username, info.Password, mobile, message)
	response, error := http.Get(apiUrl)

	if error != nil {
		return result, error
	}

	defer func() {
		response.Body.Close()
	}()

	body, error := ioutil.ReadAll(response.Body)

	if error != nil {
		return result, error
	}

	result = RawBodyToMap(body)
	return result, error
}
