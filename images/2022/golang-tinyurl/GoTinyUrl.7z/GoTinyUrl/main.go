package main

import (
	"crypto/md5"
	"fmt"
	"net/http"

	"william/utility"

	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

const DatabasePath = "./material/sqliteDB.sqlite3" // 把資料庫存放在material資料夾下

// 短網址的長相
type TinyUrl struct {
	gorm.Model
	Url  string `json:"url" gorm:"index:idx_name,unique"`
	Code string `json:"code" gorm:"index:idx_name,unique"`
}

func main() {

	database, error := createDatabase(DatabasePath)

	if error != nil {
		return
	}

	database.AutoMigrate(&TinyUrl{})
	initRouter(database)
}

// 建立資料庫
func createDatabase(path string) (*gorm.DB, error) {
	database, error := gorm.Open(sqlite.Open(path), &gorm.Config{})
	return database, error
}

// 初始化Router相關設定
func initRouter(database *gorm.DB) {

	router := gin.Default()
	router.MaxMultipartMemory = 8 << 20

	registerWebAPI(router, database)

	router.Run(":8080")
}

// 註冊API
func registerWebAPI(router *gin.Engine, database *gorm.DB) {
	insertTinyUrl(router, database)
	selectTinyUrl(router, database)
}

// MARK: - WebAPI
func insertTinyUrl(router *gin.Engine, database *gorm.DB) {

	var tinyUrl TinyUrl

	router.POST("/tinyUrl", func(context *gin.Context) {

		dictionary := utility.RequestBodyToMap(context)
		result, error := tinyUrl._Insert(database, dictionary)

		utility.ContextJSON(context, http.StatusOK, result, error)
	})
}

func selectTinyUrl(router *gin.Engine, database *gorm.DB) {

	var tinyUrl TinyUrl

	router.GET("/tinyUrl/:code", func(context *gin.Context) {

		blog := "https://william-weng.github.io/tags/golang/"
		code := context.Param("code")
		result := tinyUrl._Select(database, code)
		refreshHtml := fmt.Sprintf("<html><meta http-equiv='refresh' content='0;url=%s'/></html>", blog)

		defer func() {
			context.Data(http.StatusOK, "text/html; charset=utf-8", []byte(refreshHtml))
		}()

		if result.ID == 0 {
			return
		}

		refreshHtml = fmt.Sprintf("<html><meta http-equiv='refresh' content='0;url=%s'/></html>", result.Url)
	})
}

// 新增短網址
func (tinyUrl *TinyUrl) _Insert(database *gorm.DB, dictionary map[string]interface{}) (map[string]interface{}, error) {

	isSuccess := false

	url := dictionary["url"].(string)
	bytes := md5.Sum([]byte(url))
	code := fmt.Sprintf("%x", bytes)[:6]

	error := database.Create(&TinyUrl{Url: url, Code: code}).Error

	if error == nil {
		isSuccess = true
	}

	result := map[string]interface{}{"isSuccess": isSuccess, "code": code}
	return result, error
}

// 搜尋短網址
func (_tinyUrl *TinyUrl) _Select(database *gorm.DB, code string) TinyUrl {

	var tinyUrl TinyUrl
	database.Take(&tinyUrl, "code=?", code)

	return tinyUrl
}
