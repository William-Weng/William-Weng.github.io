package utility

import (
	"encoding/json"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// 文字 => 數字
func stringToInt(str string) (int, error) {
	return strconv.Atoi(str)
}

// 輸出JSON
func contextJSON(context *gin.Context, httpStatus int, result interface{}, error error) {

	context.JSON(httpStatus, gin.H{
		"error":  error,
		"result": result,
	})
}

// 將網路傳來的[]byte => map
func RawJSONToMap(rawJSON []byte) map[string]interface{} {

	dictionary := map[string]interface{}{}
	json.Unmarshal(rawJSON, &dictionary)

	return dictionary
}

// 尋找副檔名
func FileExtension(filename string) string {
	list := strings.Split(filename, ".")

	if len(list) < 2 {
		return ""
	}

	return list[len(list)-1]
}
