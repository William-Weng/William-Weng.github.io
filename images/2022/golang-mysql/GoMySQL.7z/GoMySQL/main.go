package main

import (
	"database/sql"
	"fmt"
	"log"
	util "william/utility" // 以go.mod上的module為root的相對位置

	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
)

func main() {

	log.SetFlags(log.LstdFlags | log.Lshortfile)

	db, error := util.ConnentDatabase()

	if error != nil {
		fmt.Println(error)
		return
	}

	router := gin.Default()
	router.MaxMultipartMemory = 8 << 20 // 8 MiB

	webAPI(router, db)

	router.Static("static", "./static") // http://localhost:8080/static <=> ./static
	router.Run(":8080")
}

// 執行API功能
func webAPI(router *gin.Engine, db *sql.DB) {
	util.UserName(router, nil)
	util.InsertBook(router, db)
	util.SelectBooks(router, db)
	util.UpdateBook(router, db)
	util.DeleteBook(router, db)
	util.UploadFile(router, nil)
	util.PushNotification(router, nil)
	util.FCM(router, nil)
}
