package utility

import (
	"database/sql"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// 建立GoBook的資料結構
type GoBook struct {
	ID         int       `json:"id"`   // <欄位> <類型> <真實在DB的欄位名稱>
	ISBN       int       `json:"isbn"` // ISBN是數字，在DB叫isbn
	Name       string    `json:"name"`
	CreateTime time.Time `json:"date"`
}

const (
	address      = "localhost"
	port         = 3306
	admin        = "root"
	password     = "12345678"
	databaseType = "mysql"
	database     = "eBook"
	table        = "GoBook"
)

// 資料庫連線 => root:12345678@tcp(localhost:3306)/eBook?charset=utf8&loc=Asia%2FShanghai&parseTime=true
func ConnentDatabase() (*sql.DB, error) {

	dataSource := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s", admin, password, address, port, database)
	dataSource += "?charset=utf8&loc=Asia%2FShanghai&parseTime=true"

	database, error := sql.Open(databaseType, dataSource)

	database.SetConnMaxLifetime(time.Duration(10) * time.Second)
	database.SetMaxOpenConns(10)
	database.SetMaxIdleConns(10)

	return database, error
}

// 簡單的GET測試 => http://localhost:8080/user/William/Welcome
func UserName(router *gin.Engine, db *sql.DB) {

	uri := "/user/:name/*action"

	router.GET(uri, func(context *gin.Context) {
		name := context.Param("name")
		action := context.Param("action")
		message := name + " is " + action
		context.String(http.StatusOK, message)
	})
}

// <Post>新增書籍 => http://localhost:8080/book/9789861079493 + form-data: name = 棋魂完全版20
func InsertBook(router *gin.Engine, db *sql.DB) {

	uri := "/book/:isbn"

	router.POST(uri, func(context *gin.Context) {

		isbn, _ := stringToInt(context.Param("isbn")) // 取url上的參數 => context.Param()
		name := context.PostForm("name")              // 取form上的參數 => context.PostForm()

		sql := "Insert Into GoBook(isbn, name) values(?, ?)"
		result, error := db.Exec(sql, isbn, name)

		contextJSON(context, http.StatusOK, result, error)
	})
}

// <Get>搜尋書籍 => http://localhost:8080/book
func SelectBooks(router *gin.Engine, db *sql.DB) {

	uri := "/book/:isbn"

	router.GET(uri, func(context *gin.Context) {

		books := []GoBook{}
		sql := "Select * From GoBook"
		rows, error := db.Query(sql)

		defer func() {
			rows.Close()
		}()

		for rows.Next() {
			var book GoBook
			rows.Scan(&book.ID, &book.ISBN, &book.Name, &book.CreateTime) // 要注意的是使用指標
			books = append(books, book)
		}

		contextJSON(context, http.StatusOK, books, error)
	})
}

// <PUT>修改某一本書籍 => http://localhost:8080/book/9789861079493
func UpdateBook(router *gin.Engine, db *sql.DB) {

	uri := "/book/:isbn"

	router.PUT(uri, func(context *gin.Context) {

		isbn, _ := stringToInt(context.Param("isbn"))      // 取url上的參數 => context.Param()
		rawJSON, _ := ioutil.ReadAll(context.Request.Body) // 讀取RawBody上的值
		sql := fmt.Sprintf("Update %s Set name=? Where isbn=?", table)

		dictionary := RawJSONToMap(rawJSON)
		name := dictionary["name"]

		result, error := db.Exec(sql, name, isbn)
		contextJSON(context, http.StatusOK, result, error)
	})
}

// <Delete>刪除某一本書籍 => http://localhost:8080/book/9789861079493
func DeleteBook(router *gin.Engine, db *sql.DB) {

	uri := "/book/:isbn"

	router.DELETE(uri, func(context *gin.Context) {

		var error error = nil
		var count int64 = 0
		var isSuccess bool = false

		defer func() {
			result := map[string]interface{}{"isSuccess": isSuccess, "count": count}
			contextJSON(context, http.StatusOK, result, error)
		}()

		isbn, error := stringToInt(context.Param("isbn"))
		if error != nil {
			return
		}

		sql := fmt.Sprintf("Delete From %s Where isbn=?", table)
		result, error := db.Exec(sql, isbn)
		if error != nil {
			return
		}

		rowsaffected, error := result.RowsAffected() // 很嚴謹的寫法會判斷RowsAffected()是否與處理的資料筆數一致
		if error != nil {
			return
		}

		isSuccess = true
		count = rowsaffected
	})
}

// 檔案上傳 => multipart/form-data, default is 32 MiB / file=<base64>
func UploadFile(router *gin.Engine, db *sql.DB) {

	key := "file"
	folder := "/Users/william.weng/Desktop/"

	router.POST("/upload", func(context *gin.Context) {

		var error error = nil
		var isSuccess bool = false
		var filename = uuid.NewString() + ".jpg"

		defer func() {
			result := map[string]interface{}{"isSuccess": isSuccess}
			contextJSON(context, http.StatusOK, result, error)
		}()

		filePath := folder + filename
		file, error := context.FormFile(key)

		if error != nil {
			return
		}

		log.Println(uuid.NewString())
		log.Println(file.Filename)

		error = context.SaveUploadedFile(file, filePath)
		if error != nil {
			return
		}

		isSuccess = true
	})
}

// 記數器 (大寫: publilc / 小寫: privete)
func Counter() func() int {
	index := 0
	return func() int {
		index++
		return index
	}
}
