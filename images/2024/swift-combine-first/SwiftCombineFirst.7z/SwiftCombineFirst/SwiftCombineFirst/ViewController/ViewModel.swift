//
//  ViewModel.swift
//  SwiftCombineFirst
//
//  Created by William.Weng on 2024/1/15.
//

import UIKit
import Combine
import WWPrint

// MARK: - ViewModel
final class RegistrationViewModel: ObservableObject {
    
    @Published var username: String = ""                                        // 帳號
    @Published var eMail: String = ""                                           // 電子郵件
    @Published var password: String = ""                                        // 密碼

    var canRegister: AnyPublisher<Bool, Never> { return canRegisterRule() }     // 可不可以註冊
}

// MARK: - 小工具
extension RegistrationViewModel {
    
    /// [清除](https://fatbobman.com/zh/posts/adding-published-ability-to-custom-property-wrapper-types/)
    func clean() {
        username = ""; eMail = ""; password = ""
    }
}

// MARK: - 小工具
private extension RegistrationViewModel {
    
    /// [可以註冊的規則 (通通要有值)](https://zhuanlan.zhihu.com/p/150958669)
    /// - Returns: [AnyPublisher<Bool, Never>](https://developer.apple.com/videos/play/wwdc2021/10022/)
    func canRegisterRule() -> AnyPublisher<Bool, Never> {
        
        let rule = Publishers.CombineLatest3($username, $eMail, $password)
            .map { username, email, password in return !username.isEmpty && !email.isEmpty && !password.isEmpty }
            .eraseToAnyPublisher()

        return rule
    }
}
