//
//  ViewController.swift
//  SwiftCombineFirst
//
//  Created by William.Weng on 2024/1/15.
//

import UIKit
import Combine
import WWPrint

// MARK: - 使用者註冊頁
final class ViewController: UIViewController {
    
    /// TextField分類
    private enum UserTextFieldType: Int, CaseIterable {
        case username = 101
        case eMail = 201
        case password = 301
    }
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var eMailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var fakeKeyboardView: UIView!
    @IBOutlet weak var keyboardHeightConstraint: NSLayoutConstraint!
    
    private var viewModel = RegistrationViewModel()
    private var cancellables: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initSetting()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        combineSetting()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        cancellables = []
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        prepareSegueAction(segue, sender: sender)
    }
    
    @IBAction private func clearInputValues(_ sender: UIBarButtonItem) {
        clearInputValuesAction()
    }
    
    deinit {
        wwPrint("[\(Self.self)] deinit")
    }
}

// MARK: - UITextFieldDelegate
extension ViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textFieldShouldReturnAction(with: textField)
    }
}

// MARK: - 小工具
private extension ViewController {
    
    /// [初始化設定](https://medium.com/彼得潘的-swift-ios-app-開發教室/37-利用scroll-view的frame-layout-guide設計浮動元件-e117d86a3f12)
    func initSetting() {
        editingChangedSetting()
    }
    
    /// [Combine的相關初始設定](https://medium.com/@puneet.teng/fetch-remote-url-with-urlsession-combine-datataskpublisher-9aa34f98b905)
    func combineSetting() {
        viewModelSetting()
        viewModelActionSetting()
        keyboardActionSetting()
    }
    
    /// [初始化設定輸入框有輸入時的動作](https://blog.csdn.net/u013538542/article/details/134426757)
    func editingChangedSetting() {
        
        keyboardHeightConstraint.constant = 0
        
        let textFields: [UserTextFieldType: UITextField] = [
            .username: usernameTextField,
            .eMail: eMailTextField,
            .password: passwordTextField,
        ]
        
        UserTextFieldType.allCases.forEach { type in
            
            guard let textField = textFields[type] else { return }
            
            textField.delegate = self
            textField.tag = type.rawValue
            textField._editingChanged { self.storeInputText(with: $0) }
        }
    }
    
    /// [把輸入的值存起來 (單向：輸入框輸入文字 -> 存變數 / 正在輸入的注音不算)](https://www.swiftbysundell.com/articles/combine-self-cancellable-memory-management/)
    /// - Parameter textField: UITextField
    func storeInputText(with textField: UITextField) {
        
        guard textField.markedTextRange == nil,
              let type = UserTextFieldType(rawValue: textField.tag)
        else {
            return
        }
        
        switch type {
        case .username: viewModel.username = textField.text ?? ""
        case .eMail: viewModel.eMail = textField.text ?? ""
        case .password: viewModel.password = textField.text ?? ""
        }
    }
    
    /// [鍵盤按下Return時的處理 (到下一個輸入框)](https://medium.com/彼得潘的-swift-ios-app-開發教室/44-利用-becomefirstresponder-練習鍵盤的顯示-6336f94f8347)
    /// - Parameter textField: UITextField
    /// - Returns: Bool
    func textFieldShouldReturnAction(with textField: UITextField) -> Bool {
        
        guard let type = UserTextFieldType(rawValue: textField.tag) else { return false }
        
        switch type {
        case .username: eMailTextField.becomeFirstResponder()
        case .eMail: passwordTextField.becomeFirstResponder()
        case .password: textField.resignFirstResponder()
        }
        
        return true
    }
    
    /// [取得鍵盤相關資訊後的相關處理](https://medium.com/彼得潘的-swift-ios-app-開發問題解答集/swiftui-view-的生命週期影響-stateobject-state-儲存的資料-ffd4982fcece)
    /// - Parameter info: [Constant.KeyboardInformation](https://waynestalk.com/swift-combine/)
    func keyboardAction(with info: Constant.KeyboardInformation) {
        
        let isHidden = info.beginFrame.origin.y < info.endFrame.origin.y
        let curve = UIView.AnimationCurve(rawValue: Int(info.curve)) ?? .linear
        keyboardHeightConstraint.constant = isHidden ? 0 : info.endFrame.height
        
        UIViewPropertyAnimator(duration: info.duration, curve: curve) {
            self.view.layoutIfNeeded()
        }.startAnimation()
    }
    
    /// [使用Segue換頁的處理](https://www.swiftbysundell.com/articles/building-swiftui-debugging-utilities/)
    /// - Parameters:
    ///   - segue: [UIStoryboardSegue](https://swiftui-lab.com/swiftui-id/)
    ///   - sender: Any?
    func prepareSegueAction(_ segue: UIStoryboardSegue, sender: Any?) {
        
        guard let nextViewController = segue.destination as? NextViewController else { return }
        
        view.endEditing(true)
        nextViewController.viewModel = viewModel
    }
    
    /// 處理註冊按鍵
    /// - Parameter canRegister: Bool
    func registerButtonSetting(canRegister: Bool) {
        registerButton.isEnabled = canRegister
        registerButton.backgroundColor = !canRegister ? .darkGray : .systemRed
    }
}

// MARK: - Combine
private extension ViewController {
    
    /// [清除輸入值 => 同時也會清除輸入框](https://onevcat.com/2020/06/stateobject/)
    func clearInputValuesAction() {
        viewModel.clean()
        view.endEditing(true)
    }
    
    /// [綁定ViewModel (單向：變數內容改變 -> 輸入框文字改變)](https://medium.com/jeremy-xue-s-blog/swift-使用-combine-處理-url-任務-8a48d0dc3b1b)
    func viewModelSetting() {
        
        viewModel.$username
            .sink { [weak self] newText in self?.usernameTextField.text = "\(newText)" }
            .onCancel { wwPrint("[onCancel] viewModel.$username") }
            .store(in: &cancellables)
        
        viewModel.$eMail
            .sink { [weak self] newText in self?.eMailTextField.text = "\(newText)" }
            .onCancel { wwPrint("[onCancel] viewModel.$eMail") }
            .store(in: &cancellables)
        
        viewModel.$password
            .sink { [weak self] newText in self?.passwordTextField.text = "\(newText)" }
            .onCancel { wwPrint("[onCancel] viewModel.$password") }
            .store(in: &cancellables)
    }
    
    /// [針對ViewModel數值改變時的處理 (註冊按鈕的顏色變化)](https://zhuanlan.zhihu.com/p/343631974)
    func viewModelActionSetting() {
        
        viewModel.canRegister
            .sink { canRegister in self.registerButtonSetting(canRegister: canRegister) }
            .onCancel { wwPrint("[onCancel] viewModel.canRegister") }
            .store(in: &cancellables)
    }
    
    /// [鍵盤出現與否的設定功能 (有點像事件通知)](https://fatbobman.com/zh/posts/exploring-key-property-wrappers-in-swiftui/)
    func keyboardActionSetting() {
                
        NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)
            .compactMap { notification in return UIDevice._keyboardInformation(notification: notification) }
            .sink { info in self.keyboardAction(with: info) }
            .onCancel { wwPrint("[onCancel] UIResponder.keyboardWillShowNotification") }
            .store(in: &cancellables)
        
        NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)
            .compactMap { notification in return UIDevice._keyboardInformation(notification: notification) }
            .sink { info in self.keyboardAction(with: info) }
            .onCancel { wwPrint("[onCancel] UIResponder.keyboardWillHideNotification") }
            .store(in: &cancellables)
    }
}

