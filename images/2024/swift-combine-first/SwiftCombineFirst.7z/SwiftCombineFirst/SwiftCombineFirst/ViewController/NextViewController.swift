//
//  NextViewController.swift
//  SwiftCombineFirst
//
//  Created by William.Weng on 2024/1/15.
//

import UIKit
import Combine
import WWPrint

// MARK: - 測試頁
final class NextViewController: UIViewController {

    typealias HttpOutput = Result<Data?, HttpError>

    enum HttpError: Error {
        case response
        case code(_ code: Int)
    }
    
    @IBOutlet weak var myImageView: UIImageView!
    
    var viewModel: RegistrationViewModel?
    
    private let imageUrl = (
        original: "https://i.ytimg.com/vi/TX9qSaGXFyg/maxresdefault.jpg",
        backup: "https://www.digitaltrends.com/wp-content/uploads/2023/06/WWDC-2023-Apple-Vision-Pro-1.jpg"
    )
    
    private var cancellables: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initSetting()
    }
    
    deinit {
        wwPrint("[\(Self.self)] deinit")
    }
}

// MARK: - 小工具
private extension NextViewController {
    
    /// [初始化設定](https://medium.com/彼得潘的-swift-ios-app-開發問題解答集/ios-combine-學習參考資源-a0ac24f348d4)
    func initSetting() {
        title = viewModel?.username
        viewModel?.clean()
        downloadImageWithURL(original: imageUrl.original, backup: imageUrl.backup)
    }
    
    /// [下載網路圖片](https://lochiwei.gitbook.io/ios/frameworks/combine/publishers/urlsession.datataskpublisher)
    /// - Parameters:
    ///   - originalUrlString: [原始圖片URL](https://www.jianshu.com/p/157978e2f283)
    ///   - backupUrlString: [備用圖片URL](https://zhuanlan.zhihu.com/p/343631974)
    func downloadImageWithURL(original originalUrlString: String, backup backupUrlString: String) {
        
        guard let originalUrl = URL(string: originalUrlString),
              let backupUrl = URL(string: backupUrlString)
        else {
            return
        }
                        
        URLSession.shared
            .dataTaskPublisher(for: originalUrl)                                                    // 將這個URL給dataTaskPublisher處理
            .receive(on: DispatchQueue.global())                                                    // 在global序執行
            .retry(3)                                                                               // 可以重試3次
            .print("[Download]")                                                                    // 顯示處理的訊息
            .catch({ error in return self.retryErrorAction(error: error, backupUrl: backupUrl) })   // 如果有錯誤的話，轉成新的dataTaskPublisher處理
            .tryMap { output -> HttpOutput in return try self.responseAction(output: output) }
            .sink { error in wwPrint(error) } receiveValue: { result in self.receiveResultAction(result: result) }
            .store(in: &cancellables)
    }
}

// MARK: - 小工具
private extension NextViewController {
    
    /// retry失敗後的處理 (下載另一張新的圖)
    /// - Parameters:
    ///   - error: URLSession.DataTaskPublisher.Failure
    ///   - backupUrl: URL
    /// - Returns: URLSession.DataTaskPublisher
    func retryErrorAction(error: URLSession.DataTaskPublisher.Failure, backupUrl: URL) -> URLSession.DataTaskPublisher {
        
        let session = URLSession(configuration: .default, delegate: nil, delegateQueue: .main)
        let publisher = session.dataTaskPublisher(for: backupUrl)
         
        return publisher
    }
    
    /// 處理取到Output而後的處理 (HTTPURLResponse)
    /// - Parameter output: URLSession.DataTaskPublisher.Output
    /// - Returns: HttpOutput
    func responseAction(output: URLSession.DataTaskPublisher.Output) throws -> HttpOutput {
        
        guard let httpResponse = output.response as? HTTPURLResponse,
              let statusCode = Optional.some(httpResponse.statusCode)
        else {
            throw HttpError.response
        }

        if (statusCode != 200) { throw HttpError.code(statusCode) }
        return HttpOutput.success(output.data)
    }
    
    /// 最後的結果處理 (網路連線正常，也有取得回應)
    /// - Parameter result: HttpOutput
    func receiveResultAction(result: HttpOutput) {
        
        switch result {
        case .failure(let error):

            switch error {
            case .code(let code): wwPrint(code)
            case .response: wwPrint("response error")
            }

        case .success(let data):
            
            guard let data = data else { return }
            
            DispatchQueue.main.async {
                wwPrint(Thread.current)
                self.myImageView.image = UIImage(data: data)
            }
            
            wwPrint(Thread.current)
        }
    }
}
