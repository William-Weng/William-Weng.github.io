//
//  Extension.swift
//  SwiftCombineFirst
//
//  Created by William.Weng on 2024/1/15.
//

import UIKit
import Combine

// MARK: - UIDevice (function)
extension UIDevice {
    
    /// [取得鍵盤相關資訊](https://medium.com/彼得潘的-swift-ios-app-開發教室/18-ios-鍵盤通知-監聽-d45bd97841a6)
    /// - UIResponder.keyboardDidShowNotification / UIResponder.keyboardDidHideNotification
    /// - Parameter notification: 鍵盤的notification
    /// - Returns: Constant.KeyboardInformation?
    static func _keyboardInformation(notification: Notification) -> Constant.KeyboardInformation? {
        
        guard let userInfo = notification.userInfo,
              let duration = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double,
              let curve = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as? UInt,
              let beginFrame = userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as? CGRect,
              let endFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
              let isLocal = userInfo[UIResponder.keyboardIsLocalUserInfoKey] as? Bool
        else {
            return nil
        }
        
        return (isLocal: isLocal, duration: duration, curve: curve, beginFrame: beginFrame, endFrame: endFrame)
    }
}

// MARK: - UIControl (function)
extension UIControl {
    
    /// [取代addTarget](https://agrawalsuneet.github.io/blogs/uitextfield-text-listener-swift/)
    /// - Parameters:
    ///   - handler: (UITextField) -> Void
    ///   - event: UIControl.Event
    func _addAction<T: UIControl>(_ handler: @escaping (T) -> Void, for event: UIControl.Event) {
        let action = UIAction() { _ in handler(self as! T) }
        self.addAction(action, for: event)
    }
}

// MARK: - UITextField (function)
extension UITextField {
    
    /// 正在輸入文字時的功能處理 (addTarget)
    /// - Parameter handler: (UITextField) -> Void
    func _editingChanged(_ handler: @escaping (UITextField) -> Void) {
        self._addAction(handler, for: .editingChanged)
    }
}

// MARK: - Cancellable (function)
extension Cancellable {
    
    /// [取得被釋放掉的回應](https://shareup.app/blog/how-to-clean-up-resources-when-a-combine-publisher-is-cancelled/)
    /// => .onCancel { print("cancelled") }.store(in: &cancellables)
    /// - Parameter closure: () -> Void
    /// - Returns: AnyCancellable
    func onCancel(_ closure: @escaping () -> Void) -> AnyCancellable {
        AnyCancellable { self.cancel(); closure() }
    }
}
