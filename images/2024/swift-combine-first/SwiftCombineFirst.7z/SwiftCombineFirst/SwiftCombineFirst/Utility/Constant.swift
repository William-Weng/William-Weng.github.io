//
//  Constant.swift
//  SwiftCombineFirst
//
//  Created by William.Weng on 2024/1/15.
//

import UIKit

// MARK: - Constant
final class Constant: NSObject {
    
    typealias KeyboardInformation = (isLocal: Bool, duration: Double, curve: UInt, beginFrame: CGRect, endFrame: CGRect)    // 取得系統鍵盤的相關資訊
}
