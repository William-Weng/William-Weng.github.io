//
//  ChatGPTAPI.swift
//  ChatGPTAPI
//
//  Created by iOS on 2024/2/17.
//

import UIKit
import WWNetworking

// MARK: - ChatGPTAPI
final class ChatGPTAPI {
    
    private let apiURL = "https://api.openai.com/v1/chat/completions"
    
    private var model = "gpt-3.5-turbo"
    private var bearerToken = "<BearerToken>"
    
    static let shared = ChatGPTAPI()
    
    private init() {}
}

// MARK: - 小工具
extension ChatGPTAPI {
    
    /// [參數設定](https://platform.openai.com/)
    /// - Parameters:
    ///   - bearerToken: [String](https://platform.openai.com/account/api-keys)
    ///   - model: [String?](https://platform.openai.com/docs/api-reference/making-requests)
    func configure(bearerToken: String, model: String? = nil) {
        self.bearerToken = bearerToken
        self.model = model ?? "gpt-3.5-turbo"
    }
    
    /// 聊天功能
    /// - Parameter content: String
    /// - Returns: Result<String?, Error>
    func chatGPT(content: String) async -> Result<String?, Error> {
        
        let headers: [String: String?] = ["Authorization": "Bearer \(bearerToken)"]
        
        let httpBody = """
        {
          "model": "\(model)",
          "messages": [{ "role": "user", "content": "\(content)" }],
          "temperature": 0.7
        }
        """
        
        let result = await WWNetworking.shared.request(with: .POST, urlString: apiURL, contentType: .json, paramaters: nil, headers: headers, httpBody: httpBody._data())
        
        var content: String?
        
        switch result {
        case .failure(let error): return .failure(error)
        case .success(let info):
            
            guard let dictionary = info.data?._jsonObject() as? [String: Any] else { return .success(content) }
            
            if let error = dictionary["error"] as? [String: Any] { return .failure(Constant.ChatGPTError.error(error)) }
            
            guard let choices = dictionary["choices"] as? [Any],
                  let choice = choices.first as? [String: Any],
                  let message = choice["message"] as? [String: Any],
                  let _content = message["content"] as? String
            else {
                return .success(content)
            }
            
            content = _content
        }
        
        return .success(content)
    }
}
