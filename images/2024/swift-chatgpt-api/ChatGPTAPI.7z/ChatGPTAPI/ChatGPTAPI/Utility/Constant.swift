//
//  Constant.swift
//  Example
//
//  Created by William.Weng on 2022/12/15.
//

import UIKit

// MARK: - Constant
final class Constant: NSObject {}

// MARK: - typealias
extension Constant {
    
    typealias KeyboardInfomation = (duration: Double, curve: UInt, frame: CGRect)           // 取得系統鍵盤的相關資訊
    typealias ChatMessage = (text: String?, isMe: Bool)
        
    enum ChatGPTError: Error {
        case error(_ error: [String: Any])
    }
    
    enum MessageType: Int {
        case text
        case image
        case video
    }
    
    enum StarSign: Int {
        
        case Aries          // 牡羊座
        case Taurus         // 金牛座
        case Gemini         // 雙子座
        case Cancer         // 巨蟹座
        case Leo            // 獅子座
        case Virgo          // 處女座
        case Libra          // 天秤座
        case Scorpio        // 天蠍座
        case Sagittarius    // 射手座
        case Capricorn      // 摩羯座
        case Aquarius       // 水瓶座
        case Pisces         // 雙魚座
        
        func id() -> String {
            
            var id = ""
            
            switch self {
            case .Aries: id = "Aries"
            case .Taurus: id = "Taurus"
            case .Gemini: id = "Gemini"
            case .Cancer: id = "Cancer"
            case .Leo: id = "Leo"
            case .Virgo: id = "Virgo"
            case .Libra: id = "Libra"
            case .Scorpio: id = "Scorpio"
            case .Sagittarius: id = "Sagittarius"
            case .Capricorn: id = "Capricorn"
            case .Aquarius: id = "Aquarius"
            case .Pisces: id = "Pisces"
            }
            
            return id
        }
        
        func name() -> String {
            
            var name = ""
            
            switch self {
            case .Aries: name = "牡羊座"
            case .Taurus: name = "金牛座"
            case .Gemini: name = "雙子座"
            case .Cancer: name = "巨蟹座"
            case .Leo: name = "獅子座"
            case .Virgo: name = "處女座"
            case .Libra: name = "天秤座"
            case .Scorpio: name = "天蠍座"
            case .Sagittarius: name = "射手座"
            case .Capricorn: name = "摩羯座"
            case .Aquarius: name = "水瓶座"
            case .Pisces: name = "雙魚座"
            }
            
            return name
        }
        
        func image() -> UIImage? {
            return UIImage(named: "\(self)")
        }
    }
}
