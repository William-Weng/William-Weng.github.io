//
//  ViewController.swift
//  Example
//
//  Created by William.Weng on 2022/12/15.
//  ~/Library/Caches/org.swift.swiftpm/
//  file:///Users/william/Desktop/WWCropViewController
// [【12星座英文】到底怎麼講？教你用英文跟大家都聊得來！-巨匠美語](https://www.soeasyedu.com.tw/blog/online-learning/2018/03/twelve-constellations)

import UIKit
import WWPrint
import PhotosUI
import WWHUD

// MARK: - 對話功能頁
final class ChatViewController: UIViewController {
    
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var myTextField: UITextField!
    @IBOutlet weak var starImageView: UIImageView!
    @IBOutlet weak var connentView: UIView!
    @IBOutlet weak var keyboardConstraintHeight: NSLayoutConstraint!
    
    static var chatMessageList: [Constant.ChatMessage] = []
    static var starSign: Constant.StarSign?
    
    private var bearerToken = "<bearerToken>"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initSetting()
        keyboardNotification()
    }
    
    @objc func keyboardWillShow(_ notification: Notification) { keyboardNotification(notification) }
    @objc func dimissKeyboard() { view.endEditing(true) }
        
    @IBAction func sendMessage(_ sender: UIButton) { sendMessage(myTextField.text) }
    
    deinit { wwPrint("deinit => \(self)") }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension ChatViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Self.chatMessageList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = chatCellMaker(tableView, cellForRowAt: indexPath) else { fatalError() }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        dimissKeyboard()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - UITextFieldDelegate
extension ChatViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

// MARK: - 小工具
private extension ChatViewController {
    
    /// 初始化設定
    func initSetting() {
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(Self.dimissKeyboard))

        myTableView.delegate = self
        myTableView.dataSource = self
        myTextField.delegate = self
        myTableView.addGestureRecognizer(tapGesture)
        
        navigationItem.titleView = UILabel._titleViewMaker(with: Self.starSign?.name(), textColor: .white)
        
        starImageView.image = Self.starSign?.image()
        keyboardConstraintHeight.constant = 0
        
        ChatGPTAPI.shared.configure(bearerToken: bearerToken)
    }
    
    /// 鍵盤顯示 / 隱藏通知設定
    func keyboardNotification() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    /// 鍵盤事件通知處理
    /// - Parameter notification: Notification
    func keyboardNotification(_ notification: Notification) {
        
        guard let info = UIDevice._keyboardInfomation(notification: notification),
              let curveType = UIView.AnimationCurve(rawValue: Int(info.curve))
        else {
            return
        }
        
        keyboardConstraintHeight.constant = view.frame.height - info.frame.origin.y
        
        let animator = UIViewPropertyAnimator(duration: info.duration, curve: curveType) { [unowned self] in
            view.layoutIfNeeded()
        }
        
        animator.startAnimation()
    }
    
    /// 選擇Cell (自己 / ChatGPT)
    /// - Parameters:
    ///   - tableView: UITableView
    ///   - indexPath: IndexPath
    /// - Returns: UITableViewCell?
    func chatCellMaker(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell? {
        
        let message = ChatViewController.chatMessageList[indexPath.row]
        
        if (!message.isMe) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SlaveTableViewCell") as? SlaveTableViewCell
            cell?.config(with: indexPath)
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MasterTableViewCell") as? MasterTableViewCell
        cell?.config(with: indexPath)
        return cell
    }
    
    /// 傳送文字訊息
    /// - Parameter message: String?
    func sendMessage(_ message: String?) {
        
        guard let message = message,
              !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let gifUrl = Bundle.main.url(forResource: "Thinking.gif", withExtension: nil),
              let gifErrorUrl = Bundle.main.url(forResource: "Shock.gif", withExtension: nil)
        else {
            return
        }
        
        let chatMessage = Constant.ChatMessage(message, true)
        let content = phaseMessage(chatMessage)
        
        if let content = content {
            
            WWHUD.shared.display(effect: .gif(url: gifUrl), height: 256, backgroundColor: .black.withAlphaComponent(0.5))
            
            Task {
                
                let result = await ChatGPTAPI.shared.chatGPT(content: content)
                
                switch result {
                case .failure(let error):
                    wwPrint(error)
                    WWHUD.shared.flash(effect: .gif(url: gifErrorUrl), height: 256, backgroundColor: .black.withAlphaComponent(0.5), animation: 1.0, completion: nil)

                case .success(let message):
                    
                    WWHUD.shared.dismiss(completion: nil)
                    
                    if let message = message {
                        let gptMessage = Constant.ChatMessage(message, false)
                        _ = phaseMessage(gptMessage)
                    }
                }
            }
        }
    }
    
    /// 解析訊息
    /// - Parameter chatMessage: Constant.ChatMessage?
    /// - Returns: String?
    func phaseMessage(_ chatMessage: Constant.ChatMessage?) -> String? {
        
        guard let chatMessage = chatMessage else { return nil }
        
        Self.chatMessageList.append(chatMessage)
        
        let indexPath = IndexPath(row: Self.chatMessageList.count - 1, section: 0)
        myTableView.insertRows(at: [indexPath], with: .none)
        myTableView.selectRow(at: indexPath, animated: true, scrollPosition: .bottom)
        myTextField.text = ""
        
        return chatMessage.text
    }
}
